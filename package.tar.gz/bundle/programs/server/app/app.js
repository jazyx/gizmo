var require = meteorInstall({"imports":{"api":{"phrases.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// imports/api/phrases.js                                                     //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
                                                                              //
let Mongo;
module.link("meteor/mongo", {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
module.exportDefault(new Mongo.Collection('phrases'));
////////////////////////////////////////////////////////////////////////////////

}}},"server":{"phrases.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// server/phrases.js                                                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
                                                                              //
module.export({
  phrases: () => phrases
});
const phrases = [{
  "src": "chickenTeeth.jpg",
  "phrase": "When chicken have teeth",
  "meaning": "Never",
  "type": "revelation"
}, {
  "src": "coolCucumber.jpg",
  "phrase": "As cool as a cucumber",
  "meaning": "Calm or relaxed",
  "type": "revelation"
}, {
  "src": "hairTeeth.jpg",
  "phrase": "To have hair on your teeth",
  "meaning": "To be self-assertive",
  "type": "revelation"
}, {
  "src": "headClouds.jpg",
  "phrase": "To have your head in the clouds",
  "meaning": "To be living in a fantasy",
  "type": "revelation"
}, {
  "src": "holdhorses.jpg",
  "phrase": "To hold your horses",
  "meaning": "To wait a moment",
  "type": "revelation"
}, {
  "src": "hotDog.jpg",
  "phrase": "The raisin at the end of the hotdog",
  "meaning": "A surprise at the end",
  "type": "revelation"
}, {
  "src": "onion.jpg",
  "phrase": "To break a fast with an onion",
  "meaning": "To get less than you expected",
  "type": "revelation"
}, {
  "src": "prawnSandwich.jpg",
  "phrase": "To slide in on a prawn sandwich",
  "meaning": "To have an easy life",
  "type": "revelation"
}, {
  "src": "tieBear.jpg",
  "phrase": "To tie a bear to someone",
  "meaning": "To confuse someone",
  "type": "revelation"
}, {
  "src": "mustardLunch.jpg",
  "phrase": "Mustard after lunch",
  "meaning": "Too late",
  "type": "revelation"
}, {
  cue: "This is a phrase with space for a missing _.",
  answer: {
    phrase: "word",
    audio: "audio/9.mp3"
  },
  distractors: [{
    phrase: "limb",
    audio: "audio/1.mp3"
  }, {
    phrase: "tooth",
    audio: "audio/1.mp3"
  }, {
    phrase: "person",
    audio: "audio/1.mp3"
  }],
  image: "question_00.jpg",
  audio: "audio/A.mp3",
  type: "recognition"
}, {
  cue: "'Twas brillig and the slithy toves did __ in the wabe",
  answer: {
    phrase: "gyre and gimble",
    audio: "audio/9.mp3"
  },
  distractors: [{
    phrase: "frolic",
    audio: "audio/2.mp3"
  }, {
    phrase: "eat their sandwiches",
    audio: "audio/2.mp3"
  }, {
    phrase: "buttonhole strangers",
    audio: "audio/2.mp3"
  }],
  image: "question_03.jpg",
  audio: "audio/7.mp3",
  type: "recognition"
}, {
  cue: "___! I'm doing the best I can.",
  answer: {
    phrase: "cut me some slack",
    audio: "audio/9.mp3"
  },
  distractors: [{
    phrase: "go back to the drawing board",
    audio: "audio/3.mp3"
  }, {
    phrase: "speak of the devil",
    audio: "audio/3.mp3"
  }, {
    phrase: "bite off more than you can chew",
    audio: "audio/3.mp3"
  }],
  image: "question_06.jpg",
  audio: "audio/7.mp3",
  type: "recognition"
}, {
  cue: "I'd _____ to be ambidextrous.",
  answer: {
    phrase: "give my right hand",
    audio: "audio/9.mp3"
  },
  distractors: [{
    phrase: "cry over spilt milk",
    audio: "audio/1.mp4"
  }, {
    phrase: "go on a wild goose chase",
    audio: "audio/4.mp3"
  }, {
    phrase: "play devil's advocate",
    audio: "audio/4.mp3"
  }],
  image: "question_12.jpg",
  audio: "audio/7.mp3",
  type: "recognition"
}, {
  cue: "I don't want to _, but no-one goes home until this is finished.",
  answer: {
    phrase: "rain on your parade",
    audio: "audio/9.mp3"
  },
  distractors: [{
    phrase: "put this on ice",
    audio: "audio/5.mp3"
  }, {
    phrase: "throw caution to the wind",
    audio: "audio/5.mp3"
  }, {
    phrase: "cut the mustard",
    audio: "audio/5.mp3"
  }],
  image: "question_18.jpg",
  audio: "audio/7.mp3",
  type: "recognition"
}];
////////////////////////////////////////////////////////////////////////////////

},"structure.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// server/structure.js                                                        //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
                                                                              //
module.export({
  createStructure: () => createStructure
});

/**
 * Run when the server launches and at any time where there is a
 * change in file that the server can see.
 * 
 * Action: recreates the file at...
 * 
 *   imports/ui/Structure.jsx
 *   
 * ... to reflect the current files at the root of the folder
 * 
 *   imports/ui/Views/
 */
var fs = require('fs');

var path = require('path');

const createStructure = () => {
  let pathArray = path.resolve("./").split("/");

  while (pathArray.pop() !== ".meteor") {}

  const ui = path.join(pathArray.join("/"), "imports/ui/");
  const output = path.join(ui, "Structure.jsx");
  const views = path.join(ui, "Views/");
  const files = fs.readdirSync(views);
  const regex = /((\d+)[_\s-]?)?([^\s]+)/;
  const imports = [];
  const components = [];
  const itemIndex = {};

  const addImport = fileName => {
    const ext = path.extname(fileName);
    const name = path.basename(fileName, ext);
    const match = regex.exec(name);

    if (!match) {
      return;
    }

    const index = parseInt(match[2], 10) || 0;
    const item = match[3][0].toUpperCase() + match[3].substring(1);
    itemIndex[item] = index;
    const line = "import ".concat(item, " from './Views/").concat(name, "'");
    imports.push(line);
    components.push(item);
  };

  files.forEach(fileName => {
    // XX_viewName
    const filePath = path.join(views, fileName);

    if (fs.lstatSync(filePath).isFile()) {
      addImport(fileName);
    }
  });
  const script = "///////////////////////////////////\n//    DO\xA0NOT\xA0MODIFY\xA0THIS\xA0FILE   \xA0//\n// IT\xA0IS\xA0GENERATED\xA0AUTOMATICALLY\xA0//\n//    BY server/structures.js    //\n///////////////////////////////////\n\n\n" + imports.join("\n") + "\n\nconst itemIndex = ".concat(JSON.stringify(itemIndex), "\n\nconst forNonZeroIndex = ( item => (\n  itemIndex[item]\n))\n\nclass Structure{\n  constructor()\xA0{\n    this.components = {\n      ").concat(components.join("\n    , "), "\n    }\n\n    const byIndex = (a, b) => (\n      itemIndex[a] - itemIndex[b]\n    )\n    this.pages = Object\n                 .keys(this.components)\n                 .filter(forNonZeroIndex)\n                 .sort(byIndex)\n                 .map( key => {\n                   const name = [key]\n                   if (this.components[key].getDisplayName) {\n                     name.push(this.components[key].getDisplayName())\n                   }\n\n                   return name\n                 })\n  }\n\n\n  getPages() {\n    return this.pages\n  }\n\n\n  viewExists(name) {\n    return !!this.components[name]\n  }\n\n\n  getComponent(name) {\n    return this.components[name]\n  }\n}\n\nexport default new Structure()");
  fs.writeFileSync(output, script);
};
////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// server/main.js                                                             //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
                                                                              //
let Meteor;
module.link("meteor/meteor", {
  Meteor(v) {
    Meteor = v;
  }

}, 0);
let Phrases;
module.link("/imports/api/phrases", {
  default(v) {
    Phrases = v;
  }

}, 1);
let phrases;
module.link("./phrases", {
  phrases(v) {
    phrases = v;
  }

}, 2);
let createStructure;
module.link("./structure", {
  createStructure(v) {
    createStructure = v;
  }

}, 3);

function insertPhrases() {
  phrases.forEach(phraseData => {
    phraseData.createdAt = new Date();
    Phrases.insert(phraseData);
  });
}

Meteor.startup(() => {
  // If the Phrases collection is empty, add some data.
  const phraseCursor = Phrases.find();
  const phraseCount = phraseCursor.count();

  if (!phraseCount) {
    insertPhrases();
  }

  if (Meteor.isDevelopment) {
    createStructure();
  }
});
////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json",
    ".ts",
    ".jsx"
  ]
});

var exports = require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9hcGkvcGhyYXNlcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3BocmFzZXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9zdHJ1Y3R1cmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIl0sIm5hbWVzIjpbIk1vbmdvIiwibW9kdWxlIiwibGluayIsInYiLCJleHBvcnREZWZhdWx0IiwiQ29sbGVjdGlvbiIsImV4cG9ydCIsInBocmFzZXMiLCJjdWUiLCJhbnN3ZXIiLCJwaHJhc2UiLCJhdWRpbyIsImRpc3RyYWN0b3JzIiwiaW1hZ2UiLCJ0eXBlIiwiY3JlYXRlU3RydWN0dXJlIiwiZnMiLCJyZXF1aXJlIiwicGF0aCIsInBhdGhBcnJheSIsInJlc29sdmUiLCJzcGxpdCIsInBvcCIsInVpIiwiam9pbiIsIm91dHB1dCIsInZpZXdzIiwiZmlsZXMiLCJyZWFkZGlyU3luYyIsInJlZ2V4IiwiaW1wb3J0cyIsImNvbXBvbmVudHMiLCJpdGVtSW5kZXgiLCJhZGRJbXBvcnQiLCJmaWxlTmFtZSIsImV4dCIsImV4dG5hbWUiLCJuYW1lIiwiYmFzZW5hbWUiLCJtYXRjaCIsImV4ZWMiLCJpbmRleCIsInBhcnNlSW50IiwiaXRlbSIsInRvVXBwZXJDYXNlIiwic3Vic3RyaW5nIiwibGluZSIsInB1c2giLCJmb3JFYWNoIiwiZmlsZVBhdGgiLCJsc3RhdFN5bmMiLCJpc0ZpbGUiLCJzY3JpcHQiLCJKU09OIiwic3RyaW5naWZ5Iiwid3JpdGVGaWxlU3luYyIsIk1ldGVvciIsIlBocmFzZXMiLCJkZWZhdWx0IiwiaW5zZXJ0UGhyYXNlcyIsInBocmFzZURhdGEiLCJjcmVhdGVkQXQiLCJEYXRlIiwiaW5zZXJ0Iiwic3RhcnR1cCIsInBocmFzZUN1cnNvciIsImZpbmQiLCJwaHJhc2VDb3VudCIsImNvdW50IiwiaXNEZXZlbG9wbWVudCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxLQUFKO0FBQVVDLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLGNBQVosRUFBMkI7QUFBQ0YsT0FBSyxDQUFDRyxDQUFELEVBQUc7QUFBQ0gsU0FBSyxHQUFDRyxDQUFOO0FBQVE7O0FBQWxCLENBQTNCLEVBQStDLENBQS9DO0FBQVZGLE1BQU0sQ0FBQ0csYUFBUCxDQUVlLElBQUlKLEtBQUssQ0FBQ0ssVUFBVixDQUFxQixTQUFyQixDQUZmLEU7Ozs7Ozs7Ozs7O0FDQUFKLE1BQU0sQ0FBQ0ssTUFBUCxDQUFjO0FBQUNDLFNBQU8sRUFBQyxNQUFJQTtBQUFiLENBQWQ7QUFBTyxNQUFNQSxPQUFPLEdBQUcsQ0FDbkI7QUFBRSxTQUFPLGtCQUFUO0FBQ0UsWUFBVSx5QkFEWjtBQUVFLGFBQVcsT0FGYjtBQUdFLFVBQVE7QUFIVixDQURtQixFQU1uQjtBQUFFLFNBQU8sa0JBQVQ7QUFDRSxZQUFVLHVCQURaO0FBRUUsYUFBVyxpQkFGYjtBQUdFLFVBQVE7QUFIVixDQU5tQixFQVduQjtBQUFFLFNBQU8sZUFBVDtBQUNFLFlBQVUsNEJBRFo7QUFFRSxhQUFXLHNCQUZiO0FBR0UsVUFBUTtBQUhWLENBWG1CLEVBZ0JuQjtBQUFFLFNBQU8sZ0JBQVQ7QUFDRSxZQUFVLGlDQURaO0FBRUUsYUFBVywyQkFGYjtBQUdFLFVBQVE7QUFIVixDQWhCbUIsRUFxQm5CO0FBQUUsU0FBTyxnQkFBVDtBQUNFLFlBQVUscUJBRFo7QUFFRSxhQUFXLGtCQUZiO0FBR0UsVUFBUTtBQUhWLENBckJtQixFQTBCbkI7QUFBRSxTQUFPLFlBQVQ7QUFDRSxZQUFVLHFDQURaO0FBRUUsYUFBVyx1QkFGYjtBQUdFLFVBQVE7QUFIVixDQTFCbUIsRUErQm5CO0FBQUUsU0FBTyxXQUFUO0FBQ0UsWUFBVSwrQkFEWjtBQUVFLGFBQVcsK0JBRmI7QUFHRSxVQUFRO0FBSFYsQ0EvQm1CLEVBb0NuQjtBQUFFLFNBQU8sbUJBQVQ7QUFDRSxZQUFVLGlDQURaO0FBRUUsYUFBVyxzQkFGYjtBQUdFLFVBQVE7QUFIVixDQXBDbUIsRUF5Q25CO0FBQUUsU0FBTyxhQUFUO0FBQ0UsWUFBVSwwQkFEWjtBQUVFLGFBQVcsb0JBRmI7QUFHRSxVQUFRO0FBSFYsQ0F6Q21CLEVBOENuQjtBQUFFLFNBQU8sa0JBQVQ7QUFDRSxZQUFVLHFCQURaO0FBRUUsYUFBVyxVQUZiO0FBR0UsVUFBUTtBQUhWLENBOUNtQixFQW9EcEI7QUFDQ0MsS0FBRyxFQUFFLDhDQUROO0FBRUNDLFFBQU0sRUFBRTtBQUFFQyxVQUFNLEVBQUUsTUFBVjtBQUFrQkMsU0FBSyxFQUFFO0FBQXpCLEdBRlQ7QUFHQ0MsYUFBVyxFQUFFLENBQ1g7QUFBRUYsVUFBTSxFQUFFLE1BQVY7QUFBa0JDLFNBQUssRUFBRTtBQUF6QixHQURXLEVBRVg7QUFBRUQsVUFBTSxFQUFFLE9BQVY7QUFBbUJDLFNBQUssRUFBRTtBQUExQixHQUZXLEVBR1g7QUFBRUQsVUFBTSxFQUFFLFFBQVY7QUFBb0JDLFNBQUssRUFBRTtBQUEzQixHQUhXLENBSGQ7QUFRQ0UsT0FBSyxFQUFFLGlCQVJSO0FBU0NGLE9BQUssRUFBRSxhQVRSO0FBVUNHLE1BQUksRUFBRTtBQVZQLENBcERvQixFQWdFckI7QUFDRU4sS0FBRyxFQUFFLHVEQURQO0FBRUVDLFFBQU0sRUFBRTtBQUFFQyxVQUFNLEVBQUUsaUJBQVY7QUFBNkJDLFNBQUssRUFBRTtBQUFwQyxHQUZWO0FBR0VDLGFBQVcsRUFBRSxDQUNYO0FBQUVGLFVBQU0sRUFBRSxRQUFWO0FBQW9CQyxTQUFLLEVBQUU7QUFBM0IsR0FEVyxFQUVYO0FBQUVELFVBQU0sRUFBRSxzQkFBVjtBQUFrQ0MsU0FBSyxFQUFFO0FBQXpDLEdBRlcsRUFHWDtBQUFFRCxVQUFNLEVBQUUsc0JBQVY7QUFBa0NDLFNBQUssRUFBRTtBQUF6QyxHQUhXLENBSGY7QUFRRUUsT0FBSyxFQUFFLGlCQVJUO0FBU0VGLE9BQUssRUFBRSxhQVRUO0FBVUVHLE1BQUksRUFBRTtBQVZSLENBaEVxQixFQTRFckI7QUFDRU4sS0FBRyxFQUFFLGdDQURQO0FBRUVDLFFBQU0sRUFBRTtBQUFFQyxVQUFNLEVBQUUsbUJBQVY7QUFBK0JDLFNBQUssRUFBRTtBQUF0QyxHQUZWO0FBR0VDLGFBQVcsRUFBRSxDQUNYO0FBQUVGLFVBQU0sRUFBRSw4QkFBVjtBQUEwQ0MsU0FBSyxFQUFFO0FBQWpELEdBRFcsRUFFWDtBQUFFRCxVQUFNLEVBQUUsb0JBQVY7QUFBZ0NDLFNBQUssRUFBRTtBQUF2QyxHQUZXLEVBR1g7QUFBRUQsVUFBTSxFQUFFLGlDQUFWO0FBQTZDQyxTQUFLLEVBQUU7QUFBcEQsR0FIVyxDQUhmO0FBUUVFLE9BQUssRUFBRSxpQkFSVDtBQVNFRixPQUFLLEVBQUUsYUFUVDtBQVVFRyxNQUFJLEVBQUU7QUFWUixDQTVFcUIsRUF3RnJCO0FBQ0VOLEtBQUcsRUFBRSwrQkFEUDtBQUVFQyxRQUFNLEVBQUU7QUFBRUMsVUFBTSxFQUFFLG9CQUFWO0FBQWdDQyxTQUFLLEVBQUU7QUFBdkMsR0FGVjtBQUdFQyxhQUFXLEVBQUUsQ0FDWDtBQUFFRixVQUFNLEVBQUUscUJBQVY7QUFBaUNDLFNBQUssRUFBRTtBQUF4QyxHQURXLEVBRVg7QUFBRUQsVUFBTSxFQUFFLDBCQUFWO0FBQXNDQyxTQUFLLEVBQUU7QUFBN0MsR0FGVyxFQUdYO0FBQUVELFVBQU0sRUFBRSx1QkFBVjtBQUFtQ0MsU0FBSyxFQUFFO0FBQTFDLEdBSFcsQ0FIZjtBQVFFRSxPQUFLLEVBQUUsaUJBUlQ7QUFTRUYsT0FBSyxFQUFFLGFBVFQ7QUFVRUcsTUFBSSxFQUFFO0FBVlIsQ0F4RnFCLEVBb0dyQjtBQUNFTixLQUFHLEVBQUUsaUVBRFA7QUFFRUMsUUFBTSxFQUFFO0FBQUVDLFVBQU0sRUFBRSxxQkFBVjtBQUFpQ0MsU0FBSyxFQUFFO0FBQXhDLEdBRlY7QUFHRUMsYUFBVyxFQUFFLENBQ1g7QUFBRUYsVUFBTSxFQUFFLGlCQUFWO0FBQTZCQyxTQUFLLEVBQUU7QUFBcEMsR0FEVyxFQUVYO0FBQUVELFVBQU0sRUFBRSwyQkFBVjtBQUF1Q0MsU0FBSyxFQUFFO0FBQTlDLEdBRlcsRUFHWDtBQUFFRCxVQUFNLEVBQUUsaUJBQVY7QUFBNkJDLFNBQUssRUFBRTtBQUFwQyxHQUhXLENBSGY7QUFRRUUsT0FBSyxFQUFFLGlCQVJUO0FBU0VGLE9BQUssRUFBRSxhQVRUO0FBVUVHLE1BQUksRUFBRTtBQVZSLENBcEdxQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0FQYixNQUFNLENBQUNLLE1BQVAsQ0FBYztBQUFDUyxpQkFBZSxFQUFDLE1BQUlBO0FBQXJCLENBQWQ7O0FBQUE7Ozs7Ozs7Ozs7OztBQWFBLElBQUlDLEVBQUUsR0FBR0MsT0FBTyxDQUFDLElBQUQsQ0FBaEI7O0FBQ0EsSUFBSUMsSUFBSSxHQUFHRCxPQUFPLENBQUMsTUFBRCxDQUFsQjs7QUFFTyxNQUFNRixlQUFlLEdBQUcsTUFBTTtBQUNuQyxNQUFJSSxTQUFTLEdBQUdELElBQUksQ0FBQ0UsT0FBTCxDQUFhLElBQWIsRUFBbUJDLEtBQW5CLENBQXlCLEdBQXpCLENBQWhCOztBQUNBLFNBQU9GLFNBQVMsQ0FBQ0csR0FBVixPQUFvQixTQUEzQixFQUFzQyxDQUFFOztBQUN4QyxRQUFNQyxFQUFFLEdBQUdMLElBQUksQ0FBQ00sSUFBTCxDQUFVTCxTQUFTLENBQUNLLElBQVYsQ0FBZSxHQUFmLENBQVYsRUFBK0IsYUFBL0IsQ0FBWDtBQUVBLFFBQU1DLE1BQU0sR0FBR1AsSUFBSSxDQUFDTSxJQUFMLENBQVVELEVBQVYsRUFBYyxlQUFkLENBQWY7QUFDQSxRQUFNRyxLQUFLLEdBQUdSLElBQUksQ0FBQ00sSUFBTCxDQUFVRCxFQUFWLEVBQWMsUUFBZCxDQUFkO0FBQ0EsUUFBTUksS0FBSyxHQUFHWCxFQUFFLENBQUNZLFdBQUgsQ0FBZUYsS0FBZixDQUFkO0FBRUEsUUFBTUcsS0FBSyxHQUFHLHlCQUFkO0FBRUEsUUFBTUMsT0FBTyxHQUFNLEVBQW5CO0FBQ0EsUUFBTUMsVUFBVSxHQUFHLEVBQW5CO0FBQ0EsUUFBTUMsU0FBUyxHQUFJLEVBQW5COztBQUVBLFFBQU1DLFNBQVMsR0FBSUMsUUFBRCxJQUFjO0FBQzlCLFVBQU1DLEdBQUcsR0FBR2pCLElBQUksQ0FBQ2tCLE9BQUwsQ0FBYUYsUUFBYixDQUFaO0FBQ0EsVUFBTUcsSUFBSSxHQUFHbkIsSUFBSSxDQUFDb0IsUUFBTCxDQUFjSixRQUFkLEVBQXdCQyxHQUF4QixDQUFiO0FBQ0EsVUFBTUksS0FBSyxHQUFHVixLQUFLLENBQUNXLElBQU4sQ0FBV0gsSUFBWCxDQUFkOztBQUNBLFFBQUksQ0FBQ0UsS0FBTCxFQUFZO0FBQ1Y7QUFDRDs7QUFFRCxVQUFNRSxLQUFLLEdBQUdDLFFBQVEsQ0FBQ0gsS0FBSyxDQUFDLENBQUQsQ0FBTixFQUFXLEVBQVgsQ0FBUixJQUEwQixDQUF4QztBQUNBLFVBQU1JLElBQUksR0FBR0osS0FBSyxDQUFDLENBQUQsQ0FBTCxDQUFTLENBQVQsRUFBWUssV0FBWixLQUE0QkwsS0FBSyxDQUFDLENBQUQsQ0FBTCxDQUFTTSxTQUFULENBQW1CLENBQW5CLENBQXpDO0FBQ0FiLGFBQVMsQ0FBQ1csSUFBRCxDQUFULEdBQWtCRixLQUFsQjtBQUVBLFVBQU1LLElBQUksb0JBQWFILElBQWIsNEJBQW1DTixJQUFuQyxNQUFWO0FBQ0FQLFdBQU8sQ0FBQ2lCLElBQVIsQ0FBY0QsSUFBZDtBQUNBZixjQUFVLENBQUNnQixJQUFYLENBQWdCSixJQUFoQjtBQUNELEdBZkQ7O0FBa0JBaEIsT0FBSyxDQUFDcUIsT0FBTixDQUFlZCxRQUFRLElBQUk7QUFBRTtBQUUzQixVQUFNZSxRQUFRLEdBQUcvQixJQUFJLENBQUNNLElBQUwsQ0FBVUUsS0FBVixFQUFpQlEsUUFBakIsQ0FBakI7O0FBQ0EsUUFBSWxCLEVBQUUsQ0FBQ2tDLFNBQUgsQ0FBYUQsUUFBYixFQUF1QkUsTUFBdkIsRUFBSixFQUFxQztBQUNuQ2xCLGVBQVMsQ0FBQ0MsUUFBRCxDQUFUO0FBQ0Q7QUFDRixHQU5EO0FBUUEsUUFBTWtCLE1BQU0sR0FBRyw2TkFRZnRCLE9BQU8sQ0FBQ04sSUFBUixDQUFhLElBQWIsQ0FSZSxtQ0FXRzZCLElBQUksQ0FBQ0MsU0FBTCxDQUFldEIsU0FBZixDQVhILHNKQW9CVEQsVUFBVSxDQUFDUCxJQUFYLENBQWdCLFVBQWhCLENBcEJTLGt1QkFBZjtBQTBEQVIsSUFBRSxDQUFDdUMsYUFBSCxDQUFpQjlCLE1BQWpCLEVBQXlCMkIsTUFBekI7QUFDRCxDQXBHTSxDOzs7Ozs7Ozs7OztBQ2hCUCxJQUFJSSxNQUFKO0FBQVd2RCxNQUFNLENBQUNDLElBQVAsQ0FBWSxlQUFaLEVBQTRCO0FBQUNzRCxRQUFNLENBQUNyRCxDQUFELEVBQUc7QUFBQ3FELFVBQU0sR0FBQ3JELENBQVA7QUFBUzs7QUFBcEIsQ0FBNUIsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSXNELE9BQUo7QUFBWXhELE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLHNCQUFaLEVBQW1DO0FBQUN3RCxTQUFPLENBQUN2RCxDQUFELEVBQUc7QUFBQ3NELFdBQU8sR0FBQ3RELENBQVI7QUFBVTs7QUFBdEIsQ0FBbkMsRUFBMkQsQ0FBM0Q7QUFBOEQsSUFBSUksT0FBSjtBQUFZTixNQUFNLENBQUNDLElBQVAsQ0FBWSxXQUFaLEVBQXdCO0FBQUNLLFNBQU8sQ0FBQ0osQ0FBRCxFQUFHO0FBQUNJLFdBQU8sR0FBQ0osQ0FBUjtBQUFVOztBQUF0QixDQUF4QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJWSxlQUFKO0FBQW9CZCxNQUFNLENBQUNDLElBQVAsQ0FBWSxhQUFaLEVBQTBCO0FBQUNhLGlCQUFlLENBQUNaLENBQUQsRUFBRztBQUFDWSxtQkFBZSxHQUFDWixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBMUIsRUFBa0UsQ0FBbEU7O0FBTTdOLFNBQVN3RCxhQUFULEdBQXlCO0FBQ3ZCcEQsU0FBTyxDQUFDeUMsT0FBUixDQUFpQlksVUFBVSxJQUFJO0FBQzdCQSxjQUFVLENBQUNDLFNBQVgsR0FBdUIsSUFBSUMsSUFBSixFQUF2QjtBQUNBTCxXQUFPLENBQUNNLE1BQVIsQ0FBZUgsVUFBZjtBQUNELEdBSEQ7QUFJRDs7QUFHREosTUFBTSxDQUFDUSxPQUFQLENBQWUsTUFBTTtBQUNuQjtBQUNBLFFBQU1DLFlBQVksR0FBR1IsT0FBTyxDQUFDUyxJQUFSLEVBQXJCO0FBQ0EsUUFBTUMsV0FBVyxHQUFHRixZQUFZLENBQUNHLEtBQWIsRUFBcEI7O0FBRUEsTUFBSSxDQUFDRCxXQUFMLEVBQWtCO0FBQ2hCUixpQkFBYTtBQUNkOztBQUVELE1BQUlILE1BQU0sQ0FBQ2EsYUFBWCxFQUEwQjtBQUN4QnRELG1CQUFlO0FBQ2hCO0FBQ0YsQ0FaRCxFIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XG5cbmV4cG9ydCBkZWZhdWx0IG5ldyBNb25nby5Db2xsZWN0aW9uKCdwaHJhc2VzJyk7XG4iLCJleHBvcnQgY29uc3QgcGhyYXNlcyA9IFtcbiAgICB7IFwic3JjXCI6IFwiY2hpY2tlblRlZXRoLmpwZ1wiXG4gICAgLCBcInBocmFzZVwiOiBcIldoZW4gY2hpY2tlbiBoYXZlIHRlZXRoXCJcbiAgICAsIFwibWVhbmluZ1wiOiBcIk5ldmVyXCJcbiAgICAsIFwidHlwZVwiOiBcInJldmVsYXRpb25cIlxuICAgIH1cbiAgLCB7IFwic3JjXCI6IFwiY29vbEN1Y3VtYmVyLmpwZ1wiXG4gICAgLCBcInBocmFzZVwiOiBcIkFzIGNvb2wgYXMgYSBjdWN1bWJlclwiXG4gICAgLCBcIm1lYW5pbmdcIjogXCJDYWxtIG9yIHJlbGF4ZWRcIlxuICAgICwgXCJ0eXBlXCI6IFwicmV2ZWxhdGlvblwiXG4gICAgfVxuICAsIHsgXCJzcmNcIjogXCJoYWlyVGVldGguanBnXCJcbiAgICAsIFwicGhyYXNlXCI6IFwiVG8gaGF2ZSBoYWlyIG9uIHlvdXIgdGVldGhcIlxuICAgICwgXCJtZWFuaW5nXCI6IFwiVG8gYmUgc2VsZi1hc3NlcnRpdmVcIlxuICAgICwgXCJ0eXBlXCI6IFwicmV2ZWxhdGlvblwiXG4gICAgfVxuICAsIHsgXCJzcmNcIjogXCJoZWFkQ2xvdWRzLmpwZ1wiXG4gICAgLCBcInBocmFzZVwiOiBcIlRvIGhhdmUgeW91ciBoZWFkIGluIHRoZSBjbG91ZHNcIlxuICAgICwgXCJtZWFuaW5nXCI6IFwiVG8gYmUgbGl2aW5nIGluIGEgZmFudGFzeVwiXG4gICAgLCBcInR5cGVcIjogXCJyZXZlbGF0aW9uXCJcbiAgICB9XG4gICwgeyBcInNyY1wiOiBcImhvbGRob3JzZXMuanBnXCJcbiAgICAsIFwicGhyYXNlXCI6IFwiVG8gaG9sZCB5b3VyIGhvcnNlc1wiXG4gICAgLCBcIm1lYW5pbmdcIjogXCJUbyB3YWl0IGEgbW9tZW50XCJcbiAgICAsIFwidHlwZVwiOiBcInJldmVsYXRpb25cIlxuICAgIH1cbiAgLCB7IFwic3JjXCI6IFwiaG90RG9nLmpwZ1wiXG4gICAgLCBcInBocmFzZVwiOiBcIlRoZSByYWlzaW4gYXQgdGhlIGVuZCBvZiB0aGUgaG90ZG9nXCJcbiAgICAsIFwibWVhbmluZ1wiOiBcIkEgc3VycHJpc2UgYXQgdGhlIGVuZFwiXG4gICAgLCBcInR5cGVcIjogXCJyZXZlbGF0aW9uXCJcbiAgICB9XG4gICwgeyBcInNyY1wiOiBcIm9uaW9uLmpwZ1wiXG4gICAgLCBcInBocmFzZVwiOiBcIlRvIGJyZWFrIGEgZmFzdCB3aXRoIGFuIG9uaW9uXCJcbiAgICAsIFwibWVhbmluZ1wiOiBcIlRvIGdldCBsZXNzIHRoYW4geW91IGV4cGVjdGVkXCJcbiAgICAsIFwidHlwZVwiOiBcInJldmVsYXRpb25cIlxuICAgIH1cbiAgLCB7IFwic3JjXCI6IFwicHJhd25TYW5kd2ljaC5qcGdcIlxuICAgICwgXCJwaHJhc2VcIjogXCJUbyBzbGlkZSBpbiBvbiBhIHByYXduIHNhbmR3aWNoXCJcbiAgICAsIFwibWVhbmluZ1wiOiBcIlRvIGhhdmUgYW4gZWFzeSBsaWZlXCJcbiAgICAsIFwidHlwZVwiOiBcInJldmVsYXRpb25cIlxuICAgIH1cbiAgLCB7IFwic3JjXCI6IFwidGllQmVhci5qcGdcIlxuICAgICwgXCJwaHJhc2VcIjogXCJUbyB0aWUgYSBiZWFyIHRvIHNvbWVvbmVcIlxuICAgICwgXCJtZWFuaW5nXCI6IFwiVG8gY29uZnVzZSBzb21lb25lXCJcbiAgICAsIFwidHlwZVwiOiBcInJldmVsYXRpb25cIlxuICAgIH1cbiAgLCB7IFwic3JjXCI6IFwibXVzdGFyZEx1bmNoLmpwZ1wiXG4gICAgLCBcInBocmFzZVwiOiBcIk11c3RhcmQgYWZ0ZXIgbHVuY2hcIlxuICAgICwgXCJtZWFuaW5nXCI6IFwiVG9vIGxhdGVcIlxuICAgICwgXCJ0eXBlXCI6IFwicmV2ZWxhdGlvblwiXG4gICAgfVxuXG4gLCB7XG4gICAgY3VlOiBcIlRoaXMgaXMgYSBwaHJhc2Ugd2l0aCBzcGFjZSBmb3IgYSBtaXNzaW5nIF8uXCJcbiAgLCBhbnN3ZXI6IHsgcGhyYXNlOiBcIndvcmRcIiwgYXVkaW86IFwiYXVkaW8vOS5tcDNcIiB9XG4gICwgZGlzdHJhY3RvcnM6IFtcbiAgICAgIHsgcGhyYXNlOiBcImxpbWJcIiwgYXVkaW86IFwiYXVkaW8vMS5tcDNcIiB9XG4gICAgLCB7IHBocmFzZTogXCJ0b290aFwiLCBhdWRpbzogXCJhdWRpby8xLm1wM1wiIH1cbiAgICAsIHsgcGhyYXNlOiBcInBlcnNvblwiLCBhdWRpbzogXCJhdWRpby8xLm1wM1wiIH1cbiAgICBdXG4gICwgaW1hZ2U6IFwicXVlc3Rpb25fMDAuanBnXCJcbiAgLCBhdWRpbzogXCJhdWRpby9BLm1wM1wiXG4gICwgdHlwZTogXCJyZWNvZ25pdGlvblwiXG4gIH1cbiwge1xuICAgIGN1ZTogXCInVHdhcyBicmlsbGlnIGFuZCB0aGUgc2xpdGh5IHRvdmVzIGRpZCBfXyBpbiB0aGUgd2FiZVwiXG4gICwgYW5zd2VyOiB7IHBocmFzZTogXCJneXJlIGFuZCBnaW1ibGVcIiwgYXVkaW86IFwiYXVkaW8vOS5tcDNcIiB9XG4gICwgZGlzdHJhY3RvcnM6IFtcbiAgICAgIHsgcGhyYXNlOiBcImZyb2xpY1wiLCBhdWRpbzogXCJhdWRpby8yLm1wM1wiIH1cbiAgICAsIHsgcGhyYXNlOiBcImVhdCB0aGVpciBzYW5kd2ljaGVzXCIsIGF1ZGlvOiBcImF1ZGlvLzIubXAzXCIgfVxuICAgICwgeyBwaHJhc2U6IFwiYnV0dG9uaG9sZSBzdHJhbmdlcnNcIiwgYXVkaW86IFwiYXVkaW8vMi5tcDNcIiB9XG4gICAgXVxuICAsIGltYWdlOiBcInF1ZXN0aW9uXzAzLmpwZ1wiXG4gICwgYXVkaW86IFwiYXVkaW8vNy5tcDNcIlxuICAsIHR5cGU6IFwicmVjb2duaXRpb25cIlxuICB9XG4sIHtcbiAgICBjdWU6IFwiX19fISBJJ20gZG9pbmcgdGhlIGJlc3QgSSBjYW4uXCJcbiAgLCBhbnN3ZXI6IHsgcGhyYXNlOiBcImN1dCBtZSBzb21lIHNsYWNrXCIsIGF1ZGlvOiBcImF1ZGlvLzkubXAzXCIgfVxuICAsIGRpc3RyYWN0b3JzOiBbXG4gICAgICB7IHBocmFzZTogXCJnbyBiYWNrIHRvIHRoZSBkcmF3aW5nIGJvYXJkXCIsIGF1ZGlvOiBcImF1ZGlvLzMubXAzXCIgfVxuICAgICwgeyBwaHJhc2U6IFwic3BlYWsgb2YgdGhlIGRldmlsXCIsIGF1ZGlvOiBcImF1ZGlvLzMubXAzXCIgfVxuICAgICwgeyBwaHJhc2U6IFwiYml0ZSBvZmYgbW9yZSB0aGFuIHlvdSBjYW4gY2hld1wiLCBhdWRpbzogXCJhdWRpby8zLm1wM1wiIH1cbiAgICBdXG4gICwgaW1hZ2U6IFwicXVlc3Rpb25fMDYuanBnXCJcbiAgLCBhdWRpbzogXCJhdWRpby83Lm1wM1wiXG4gICwgdHlwZTogXCJyZWNvZ25pdGlvblwiXG4gIH1cbiwge1xuICAgIGN1ZTogXCJJJ2QgX19fX18gdG8gYmUgYW1iaWRleHRyb3VzLlwiXG4gICwgYW5zd2VyOiB7IHBocmFzZTogXCJnaXZlIG15IHJpZ2h0IGhhbmRcIiwgYXVkaW86IFwiYXVkaW8vOS5tcDNcIiB9XG4gICwgZGlzdHJhY3RvcnM6IFtcbiAgICAgIHsgcGhyYXNlOiBcImNyeSBvdmVyIHNwaWx0IG1pbGtcIiwgYXVkaW86IFwiYXVkaW8vMS5tcDRcIiB9XG4gICAgLCB7IHBocmFzZTogXCJnbyBvbiBhIHdpbGQgZ29vc2UgY2hhc2VcIiwgYXVkaW86IFwiYXVkaW8vNC5tcDNcIiB9XG4gICAgLCB7IHBocmFzZTogXCJwbGF5IGRldmlsJ3MgYWR2b2NhdGVcIiwgYXVkaW86IFwiYXVkaW8vNC5tcDNcIiB9XG4gICAgXVxuICAsIGltYWdlOiBcInF1ZXN0aW9uXzEyLmpwZ1wiXG4gICwgYXVkaW86IFwiYXVkaW8vNy5tcDNcIlxuICAsIHR5cGU6IFwicmVjb2duaXRpb25cIlxuICB9XG4sIHtcbiAgICBjdWU6IFwiSSBkb24ndCB3YW50IHRvIF8sIGJ1dCBuby1vbmUgZ29lcyBob21lIHVudGlsIHRoaXMgaXMgZmluaXNoZWQuXCJcbiAgLCBhbnN3ZXI6IHsgcGhyYXNlOiBcInJhaW4gb24geW91ciBwYXJhZGVcIiwgYXVkaW86IFwiYXVkaW8vOS5tcDNcIiB9XG4gICwgZGlzdHJhY3RvcnM6IFtcbiAgICAgIHsgcGhyYXNlOiBcInB1dCB0aGlzIG9uIGljZVwiLCBhdWRpbzogXCJhdWRpby81Lm1wM1wiIH1cbiAgICAsIHsgcGhyYXNlOiBcInRocm93IGNhdXRpb24gdG8gdGhlIHdpbmRcIiwgYXVkaW86IFwiYXVkaW8vNS5tcDNcIiB9XG4gICAgLCB7IHBocmFzZTogXCJjdXQgdGhlIG11c3RhcmRcIiwgYXVkaW86IFwiYXVkaW8vNS5tcDNcIiB9XG4gICAgXVxuICAsIGltYWdlOiBcInF1ZXN0aW9uXzE4LmpwZ1wiXG4gICwgYXVkaW86IFwiYXVkaW8vNy5tcDNcIlxuICAsIHR5cGU6IFwicmVjb2duaXRpb25cIlxuICB9XG5dIiwiLyoqXG4gKiBSdW4gd2hlbiB0aGUgc2VydmVyIGxhdW5jaGVzIGFuZCBhdCBhbnkgdGltZSB3aGVyZSB0aGVyZSBpcyBhXG4gKiBjaGFuZ2UgaW4gZmlsZSB0aGF0IHRoZSBzZXJ2ZXIgY2FuIHNlZS5cbiAqIFxuICogQWN0aW9uOiByZWNyZWF0ZXMgdGhlIGZpbGUgYXQuLi5cbiAqIFxuICogICBpbXBvcnRzL3VpL1N0cnVjdHVyZS5qc3hcbiAqICAgXG4gKiAuLi4gdG8gcmVmbGVjdCB0aGUgY3VycmVudCBmaWxlcyBhdCB0aGUgcm9vdCBvZiB0aGUgZm9sZGVyXG4gKiBcbiAqICAgaW1wb3J0cy91aS9WaWV3cy9cbiAqL1xuXG52YXIgZnMgPSByZXF1aXJlKCdmcycpO1xudmFyIHBhdGggPSByZXF1aXJlKCdwYXRoJyk7XG5cbmV4cG9ydCBjb25zdCBjcmVhdGVTdHJ1Y3R1cmUgPSAoKSA9PiB7XG4gIGxldCBwYXRoQXJyYXkgPSBwYXRoLnJlc29sdmUoXCIuL1wiKS5zcGxpdChcIi9cIilcbiAgd2hpbGUgKHBhdGhBcnJheS5wb3AoKSAhPT0gXCIubWV0ZW9yXCIpIHt9ICAgIFxuICBjb25zdCB1aSA9IHBhdGguam9pbihwYXRoQXJyYXkuam9pbihcIi9cIiksIFwiaW1wb3J0cy91aS9cIilcblxuICBjb25zdCBvdXRwdXQgPSBwYXRoLmpvaW4odWksIFwiU3RydWN0dXJlLmpzeFwiKVxuICBjb25zdCB2aWV3cyA9IHBhdGguam9pbih1aSwgXCJWaWV3cy9cIilcbiAgY29uc3QgZmlsZXMgPSBmcy5yZWFkZGlyU3luYyh2aWV3cylcblxuICBjb25zdCByZWdleCA9IC8oKFxcZCspW19cXHMtXT8pPyhbXlxcc10rKS9cblxuICBjb25zdCBpbXBvcnRzICAgID0gW11cbiAgY29uc3QgY29tcG9uZW50cyA9IFtdXG4gIGNvbnN0IGl0ZW1JbmRleCAgPSB7fVxuXG4gIGNvbnN0IGFkZEltcG9ydCA9IChmaWxlTmFtZSkgPT4ge1xuICAgIGNvbnN0IGV4dCA9IHBhdGguZXh0bmFtZShmaWxlTmFtZSlcbiAgICBjb25zdCBuYW1lID0gcGF0aC5iYXNlbmFtZShmaWxlTmFtZSwgZXh0KVxuICAgIGNvbnN0IG1hdGNoID0gcmVnZXguZXhlYyhuYW1lKVxuICAgIGlmICghbWF0Y2gpIHtcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGNvbnN0IGluZGV4ID0gcGFyc2VJbnQobWF0Y2hbMl0sIDEwKSB8fMKgMFxuICAgIGNvbnN0IGl0ZW0gPSBtYXRjaFszXVswXS50b1VwcGVyQ2FzZSgpICsgbWF0Y2hbM10uc3Vic3RyaW5nKDEpXG4gICAgaXRlbUluZGV4W2l0ZW1dID0gaW5kZXhcblxuICAgIGNvbnN0IGxpbmUgPSBgaW1wb3J0ICR7aXRlbX0gZnJvbSAnLi9WaWV3cy8ke25hbWV9J2BcbiAgICBpbXBvcnRzLnB1c2ggKGxpbmUpXG4gICAgY29tcG9uZW50cy5wdXNoKGl0ZW0pXG4gIH1cblxuXG4gIGZpbGVzLmZvckVhY2goIGZpbGVOYW1lID0+IHsgLy8gWFhfdmlld05hbWVcblxuICAgIGNvbnN0IGZpbGVQYXRoID0gcGF0aC5qb2luKHZpZXdzLCBmaWxlTmFtZSlcbiAgICBpZiAoZnMubHN0YXRTeW5jKGZpbGVQYXRoKS5pc0ZpbGUoKSkge1xuICAgICAgYWRkSW1wb3J0KGZpbGVOYW1lKVxuICAgIH1cbiAgfSlcblxuICBjb25zdCBzY3JpcHQgPSBgLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy9cbi8vICAgIERPwqBOT1TCoE1PRElGWcKgVEhJU8KgRklMRSAgIMKgLy9cbi8vIElUwqBJU8KgR0VORVJBVEVEwqBBVVRPTUFUSUNBTExZwqAvL1xuLy8gICAgQlkgc2VydmVyL3N0cnVjdHVyZXMuanMgICAgLy9cbi8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vLy8vXG5cblxuYFxuKyBpbXBvcnRzLmpvaW4oXCJcXG5cIilcbisgYFxuXG5jb25zdCBpdGVtSW5kZXggPSAke0pTT04uc3RyaW5naWZ5KGl0ZW1JbmRleCl9XG5cbmNvbnN0IGZvck5vblplcm9JbmRleCA9ICggaXRlbSA9PiAoXG4gIGl0ZW1JbmRleFtpdGVtXVxuKSlcblxuY2xhc3MgU3RydWN0dXJle1xuICBjb25zdHJ1Y3RvcigpwqB7XG4gICAgdGhpcy5jb21wb25lbnRzID0ge1xuICAgICAgJHtjb21wb25lbnRzLmpvaW4oXCJcXG4gICAgLCBcIil9XG4gICAgfVxuXG4gICAgY29uc3QgYnlJbmRleCA9IChhLCBiKSA9PiAoXG4gICAgICBpdGVtSW5kZXhbYV0gLSBpdGVtSW5kZXhbYl1cbiAgICApXG4gICAgdGhpcy5wYWdlcyA9IE9iamVjdFxuICAgICAgICAgICAgICAgICAua2V5cyh0aGlzLmNvbXBvbmVudHMpXG4gICAgICAgICAgICAgICAgIC5maWx0ZXIoZm9yTm9uWmVyb0luZGV4KVxuICAgICAgICAgICAgICAgICAuc29ydChieUluZGV4KVxuICAgICAgICAgICAgICAgICAubWFwKCBrZXkgPT4ge1xuICAgICAgICAgICAgICAgICAgIGNvbnN0IG5hbWUgPSBba2V5XVxuICAgICAgICAgICAgICAgICAgIGlmICh0aGlzLmNvbXBvbmVudHNba2V5XS5nZXREaXNwbGF5TmFtZSkge1xuICAgICAgICAgICAgICAgICAgICAgbmFtZS5wdXNoKHRoaXMuY29tcG9uZW50c1trZXldLmdldERpc3BsYXlOYW1lKCkpXG4gICAgICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgICAgcmV0dXJuIG5hbWVcbiAgICAgICAgICAgICAgICAgfSlcbiAgfVxuXG5cbiAgZ2V0UGFnZXMoKSB7XG4gICAgcmV0dXJuIHRoaXMucGFnZXNcbiAgfVxuXG5cbiAgdmlld0V4aXN0cyhuYW1lKSB7XG4gICAgcmV0dXJuICEhdGhpcy5jb21wb25lbnRzW25hbWVdXG4gIH1cblxuXG4gIGdldENvbXBvbmVudChuYW1lKSB7XG4gICAgcmV0dXJuIHRoaXMuY29tcG9uZW50c1tuYW1lXVxuICB9XG59XG5cbmV4cG9ydCBkZWZhdWx0IG5ldyBTdHJ1Y3R1cmUoKWBcblxuICBmcy53cml0ZUZpbGVTeW5jKG91dHB1dCwgc2NyaXB0KVxufSIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IFBocmFzZXMgZnJvbSAnL2ltcG9ydHMvYXBpL3BocmFzZXMnO1xuaW1wb3J0IHsgcGhyYXNlcyB9IGZyb20gJy4vcGhyYXNlcydcbmltcG9ydCB7IGNyZWF0ZVN0cnVjdHVyZSB9IGZyb20gJy4vc3RydWN0dXJlJ1xuXG5cbmZ1bmN0aW9uIGluc2VydFBocmFzZXMoKSB7XG4gIHBocmFzZXMuZm9yRWFjaCggcGhyYXNlRGF0YSA9PiB7XG4gICAgcGhyYXNlRGF0YS5jcmVhdGVkQXQgPSBuZXcgRGF0ZSgpXG4gICAgUGhyYXNlcy5pbnNlcnQocGhyYXNlRGF0YSlcbiAgfSlcbn1cblxuXG5NZXRlb3Iuc3RhcnR1cCgoKSA9PiB7XG4gIC8vIElmIHRoZSBQaHJhc2VzIGNvbGxlY3Rpb24gaXMgZW1wdHksIGFkZCBzb21lIGRhdGEuXG4gIGNvbnN0IHBocmFzZUN1cnNvciA9IFBocmFzZXMuZmluZCgpXG4gIGNvbnN0IHBocmFzZUNvdW50ID0gcGhyYXNlQ3Vyc29yLmNvdW50KClcblxuICBpZiAoIXBocmFzZUNvdW50KSB7XG4gICAgaW5zZXJ0UGhyYXNlcygpXG4gIH1cblxuICBpZiAoTWV0ZW9yLmlzRGV2ZWxvcG1lbnQpIHtcbiAgICBjcmVhdGVTdHJ1Y3R1cmUoKVxuICB9XG59KTtcbiJdfQ==
