(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var Tracker = Package.tracker.Tracker;
var Deps = Package.tracker.Deps;
var ECMAScript = Package.ecmascript.ECMAScript;
var meteorInstall = Package.modules.meteorInstall;
var Promise = Package.promise.Promise;

var require = meteorInstall({"node_modules":{"meteor":{"react-meteor-data":{"index.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/react-meteor-data/index.js                                                                         //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let React;
module.link("react", {
  default(v) {
    React = v;
  }

}, 0);
module.link("./useTracker", {
  default: "useTracker"
}, 1);
module.link("./withTracker.jsx", {
  default: "withTracker"
}, 2);

if (Meteor.isDevelopment) {
  const v = React.version.split('.');

  if (v[0] < 16 || v[1] < 8) {
    console.warn('react-meteor-data 2.x requires React version >= 16.8.');
  }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"useTracker.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/react-meteor-data/useTracker.js                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let React, useReducer, useEffect, useRef, useMemo;
module.link("react", {
  default(v) {
    React = v;
  },

  useReducer(v) {
    useReducer = v;
  },

  useEffect(v) {
    useEffect = v;
  },

  useRef(v) {
    useRef = v;
  },

  useMemo(v) {
    useMemo = v;
  }

}, 0);
// Use React.warn() if available (should ship in React 16.9).
const warn = React.warn || console.warn.bind(console); // Warns if data is a Mongo.Cursor or a POJO containing a Mongo.Cursor.

function checkCursor(data) {
  let shouldWarn = false;

  if (Package.mongo && Package.mongo.Mongo && data && typeof data === 'object') {
    if (data instanceof Package.mongo.Mongo.Cursor) {
      shouldWarn = true;
    } else if (Object.getPrototypeOf(data) === Object.prototype) {
      Object.keys(data).forEach(key => {
        if (data[key] instanceof Package.mongo.Mongo.Cursor) {
          shouldWarn = true;
        }
      });
    }
  }

  if (shouldWarn) {
    warn('Warning: your reactive function is returning a Mongo cursor. ' + 'This value will not be reactive. You probably want to call ' + '`.fetch()` on the cursor before returning it.');
  }
} // Used to create a forceUpdate from useReducer. Forces update by
// incrementing a number whenever the dispatch method is invoked.


const fur = x => x + 1; // The follow functions were hoisted out of the closure to reduce allocations.
// Since they no longer have access to the local vars, we pass them in and mutate here.

/* eslint-disable no-param-reassign */


const dispose = refs => {
  if (refs.computationCleanup) {
    refs.computationCleanup();
    delete refs.computationCleanup;
  }

  if (refs.computation) {
    refs.computation.stop();
    refs.computation = null;
  }
};

const runReactiveFn = Meteor.isDevelopment ? (refs, c) => {
  const data = refs.reactiveFn(c);
  checkCursor(data);
  refs.trackerData = data;
} : (refs, c) => {
  refs.trackerData = refs.reactiveFn(c);
};

const clear = refs => {
  if (refs.disposeId) {
    clearTimeout(refs.disposeId);
    delete refs.disposeId;
  }
};

const tracked = (refs, c, forceUpdate) => {
  if (c.firstRun) {
    // If there is a computationHandler, pass it the computation, and store the
    // result, which may be a cleanup method.
    if (refs.computationHandler) {
      const cleanupHandler = refs.computationHandler(c);

      if (cleanupHandler) {
        if (Meteor.isDevelopment && typeof cleanupHandler !== 'function') {
          warn('Warning: Computation handler should return a function ' + 'to be used for cleanup or return nothing.');
        }

        refs.computationCleanup = cleanupHandler;
      }
    } // Always run the reactiveFn on firstRun


    runReactiveFn(refs, c);
  } else {
    // If deps are anything other than an array, stop computation and let next render
    // handle reactiveFn. These null and undefined checks are optimizations to avoid
    // calling Array.isArray in these cases.
    if (refs.deps === null || refs.deps === undefined || !Array.isArray(refs.deps)) {
      dispose(refs);
      forceUpdate();
    } else if (refs.isMounted) {
      // Only run the reactiveFn if the component is mounted.
      runReactiveFn(refs, c);
      forceUpdate();
    } else {
      // If we got here, then a reactive update happened before the render was
      // committed - before useEffect has run. We don't want to run the reactiveFn
      // while we are not sure this render will be committed, so we'll dispose of the
      // computation, and set everything up to be restarted in useEffect if needed.
      // NOTE: If we don't run the user's reactiveFn when a computation updates, we'll
      // leave the computation in a non-reactive state - so we'll dispose here and let
      // the useEffect hook recreate the computation later.
      dispose(refs); // Might as well clear the timeout!

      clear(refs);
    }
  }
};
/* eslint-enable no-param-reassign */


function useTrackerClient(reactiveFn, deps, computationHandler) {
  const {
    current: refs
  } = useRef({});
  const [, forceUpdate] = useReducer(fur, 0); // Always have up to date deps and computations in all contexts

  refs.reactiveFn = reactiveFn;
  refs.deps = deps;
  refs.computationHandler = computationHandler; // We are abusing useMemo a little bit, using it for it's deps
  // compare, but not for it's memoization.

  useMemo(() => {
    // if we are re-creating the computation, we need to stop the old one.
    dispose(refs); // Use Tracker.nonreactive in case we are inside a Tracker Computation.
    // This can happen if someone calls `ReactDOM.render` inside a Computation.
    // In that case, we want to opt out of the normal behavior of nested
    // Computations, where if the outer one is invalidated or stopped,
    // it stops the inner one.

    refs.computation = Tracker.nonreactive(() => Tracker.autorun(c => {
      tracked(refs, c, forceUpdate);
    })); // We are creating a side effect in render, which can be problematic in some cases, such as
    // Suspense or concurrent rendering or if an error is thrown and handled by an error boundary.
    // We still want synchronous rendering for a number of reason (see readme), so we work around
    // possible memory/resource leaks by setting a time out to automatically clean everything up,
    // and watching a set of references to make sure everything is choreographed correctly.

    if (!refs.isMounted) {
      // Components yield to allow the DOM to update and the browser to paint before useEffect
      // is run. In concurrent mode this can take quite a long time, so we set a 1000ms timeout
      // to allow for that.
      refs.disposeId = setTimeout(() => {
        if (!refs.isMounted) {
          dispose(refs);
        }
      }, 1000);
    }
  }, deps);
  useEffect(() => {
    // Now that we are mounted, we can set the flag, and cancel the timeout
    refs.isMounted = true; // We are committed, clear the dispose timeout

    clear(refs); // If it took longer than 1000ms to get to useEffect, or a reactive update happened
    // before useEffect, we will need to forceUpdate, and restart the computation.

    if (!refs.computation) {
      // If we have deps, we need to set up a new computation before forcing update.
      // If we have NO deps, it'll be recreated and rerun on the next render.
      if (Array.isArray(deps)) {
        // This also runs runReactiveFn
        refs.computation = Tracker.nonreactive(() => Tracker.autorun(c => {
          tracked(refs, c, forceUpdate);
        }));
      }

      forceUpdate();
    } // stop the computation on unmount


    return () => dispose(refs);
  }, []);
  return refs.trackerData;
} // When rendering on the server, we don't want to use the Tracker.
// We only do the first rendering on the server so we can get the data right away


const useTracker = Meteor.isServer ? reactiveFn => Tracker.nonreactive(reactiveFn) : useTrackerClient;
module.exportDefault(Meteor.isDevelopment ? (reactiveFn, deps, computationHandler) => {
  if (typeof reactiveFn !== 'function') {
    warn('Warning: useTracker expected a function in it\'s first argument ' + "(reactiveFn), but got type of ".concat(typeof reactiveFn, "."));
  }

  if (deps && !Array.isArray(deps)) {
    warn('Warning: useTracker expected an array in it\'s second argument ' + "(dependency), but got type of ".concat(typeof deps, "."));
  }

  if (computationHandler && typeof computationHandler !== 'function') {
    warn('Warning: useTracker expected a function in it\'s third argument' + "(computationHandler), but got type of ".concat(typeof computationHandler, "."));
  }

  return useTracker(reactiveFn, deps, computationHandler);
} : useTracker);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"withTracker.jsx":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// packages/react-meteor-data/withTracker.jsx                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let _extends;

module.link("@babel/runtime/helpers/extends", {
  default(v) {
    _extends = v;
  }

}, 0);
module.export({
  default: () => withTracker
});
let React, forwardRef, memo;
module.link("react", {
  default(v) {
    React = v;
  },

  forwardRef(v) {
    forwardRef = v;
  },

  memo(v) {
    memo = v;
  }

}, 0);
let useTracker;
module.link("./useTracker.js", {
  default(v) {
    useTracker = v;
  }

}, 1);

function withTracker(options) {
  return Component => {
    const expandedOptions = typeof options === 'function' ? {
      getMeteorData: options
    } : options;
    const {
      getMeteorData,
      pure = true
    } = expandedOptions;
    const WithTracker = forwardRef((props, ref) => {
      const data = useTracker(() => getMeteorData(props) || {});
      return React.createElement(Component, _extends({
        ref: ref
      }, props, data));
    });
    return pure ? memo(WithTracker) : WithTracker;
  };
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}}},{
  "extensions": [
    ".js",
    ".json",
    ".jsx"
  ]
});

var exports = require("/node_modules/meteor/react-meteor-data/index.js");

/* Exports */
Package._define("react-meteor-data", exports);

})();

//# sourceURL=meteor://💻app/packages/react-meteor-data.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvcGFja2FnZXMvcmVhY3QtbWV0ZW9yLWRhdGEvaW5kZXguanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3JlYWN0LW1ldGVvci1kYXRhL3VzZVRyYWNrZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3BhY2thZ2VzL3JlYWN0LW1ldGVvci1kYXRhL3dpdGhUcmFja2VyLmpzeCJdLCJuYW1lcyI6WyJSZWFjdCIsIm1vZHVsZSIsImxpbmsiLCJkZWZhdWx0IiwidiIsIk1ldGVvciIsImlzRGV2ZWxvcG1lbnQiLCJ2ZXJzaW9uIiwic3BsaXQiLCJjb25zb2xlIiwid2FybiIsInVzZVJlZHVjZXIiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJ1c2VNZW1vIiwiYmluZCIsImNoZWNrQ3Vyc29yIiwiZGF0YSIsInNob3VsZFdhcm4iLCJQYWNrYWdlIiwibW9uZ28iLCJNb25nbyIsIkN1cnNvciIsIk9iamVjdCIsImdldFByb3RvdHlwZU9mIiwicHJvdG90eXBlIiwia2V5cyIsImZvckVhY2giLCJrZXkiLCJmdXIiLCJ4IiwiZGlzcG9zZSIsInJlZnMiLCJjb21wdXRhdGlvbkNsZWFudXAiLCJjb21wdXRhdGlvbiIsInN0b3AiLCJydW5SZWFjdGl2ZUZuIiwiYyIsInJlYWN0aXZlRm4iLCJ0cmFja2VyRGF0YSIsImNsZWFyIiwiZGlzcG9zZUlkIiwiY2xlYXJUaW1lb3V0IiwidHJhY2tlZCIsImZvcmNlVXBkYXRlIiwiZmlyc3RSdW4iLCJjb21wdXRhdGlvbkhhbmRsZXIiLCJjbGVhbnVwSGFuZGxlciIsImRlcHMiLCJ1bmRlZmluZWQiLCJBcnJheSIsImlzQXJyYXkiLCJpc01vdW50ZWQiLCJ1c2VUcmFja2VyQ2xpZW50IiwiY3VycmVudCIsIlRyYWNrZXIiLCJub25yZWFjdGl2ZSIsImF1dG9ydW4iLCJzZXRUaW1lb3V0IiwidXNlVHJhY2tlciIsImlzU2VydmVyIiwiZXhwb3J0RGVmYXVsdCIsIl9leHRlbmRzIiwiZXhwb3J0Iiwid2l0aFRyYWNrZXIiLCJmb3J3YXJkUmVmIiwibWVtbyIsIm9wdGlvbnMiLCJDb21wb25lbnQiLCJleHBhbmRlZE9wdGlvbnMiLCJnZXRNZXRlb3JEYXRhIiwicHVyZSIsIldpdGhUcmFja2VyIiwicHJvcHMiLCJyZWYiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsS0FBSjtBQUFVQyxNQUFNLENBQUNDLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFROztBQUFwQixDQUFwQixFQUEwQyxDQUExQztBQUE2Q0gsTUFBTSxDQUFDQyxJQUFQLENBQVksY0FBWixFQUEyQjtBQUFDQyxTQUFPLEVBQUM7QUFBVCxDQUEzQixFQUFrRCxDQUFsRDtBQUFxREYsTUFBTSxDQUFDQyxJQUFQLENBQVksbUJBQVosRUFBZ0M7QUFBQ0MsU0FBTyxFQUFDO0FBQVQsQ0FBaEMsRUFBd0QsQ0FBeEQ7O0FBRzVHLElBQUlFLE1BQU0sQ0FBQ0MsYUFBWCxFQUEwQjtBQUN4QixRQUFNRixDQUFDLEdBQUdKLEtBQUssQ0FBQ08sT0FBTixDQUFjQyxLQUFkLENBQW9CLEdBQXBCLENBQVY7O0FBQ0EsTUFBSUosQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLEVBQVAsSUFBYUEsQ0FBQyxDQUFDLENBQUQsQ0FBRCxHQUFPLENBQXhCLEVBQTJCO0FBQ3pCSyxXQUFPLENBQUNDLElBQVIsQ0FBYSx1REFBYjtBQUNEO0FBQ0YsQzs7Ozs7Ozs7Ozs7QUNSRCxJQUFJVixLQUFKLEVBQVVXLFVBQVYsRUFBcUJDLFNBQXJCLEVBQStCQyxNQUEvQixFQUFzQ0MsT0FBdEM7QUFBOENiLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZLE9BQVosRUFBb0I7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ0osU0FBSyxHQUFDSSxDQUFOO0FBQVEsR0FBcEI7O0FBQXFCTyxZQUFVLENBQUNQLENBQUQsRUFBRztBQUFDTyxjQUFVLEdBQUNQLENBQVg7QUFBYSxHQUFoRDs7QUFBaURRLFdBQVMsQ0FBQ1IsQ0FBRCxFQUFHO0FBQUNRLGFBQVMsR0FBQ1IsQ0FBVjtBQUFZLEdBQTFFOztBQUEyRVMsUUFBTSxDQUFDVCxDQUFELEVBQUc7QUFBQ1MsVUFBTSxHQUFDVCxDQUFQO0FBQVMsR0FBOUY7O0FBQStGVSxTQUFPLENBQUNWLENBQUQsRUFBRztBQUFDVSxXQUFPLEdBQUNWLENBQVI7QUFBVTs7QUFBcEgsQ0FBcEIsRUFBMEksQ0FBMUk7QUFHOUM7QUFDQSxNQUFNTSxJQUFJLEdBQUdWLEtBQUssQ0FBQ1UsSUFBTixJQUFjRCxPQUFPLENBQUNDLElBQVIsQ0FBYUssSUFBYixDQUFrQk4sT0FBbEIsQ0FBM0IsQyxDQUVBOztBQUNBLFNBQVNPLFdBQVQsQ0FBcUJDLElBQXJCLEVBQTJCO0FBQ3pCLE1BQUlDLFVBQVUsR0FBRyxLQUFqQjs7QUFDQSxNQUFJQyxPQUFPLENBQUNDLEtBQVIsSUFBaUJELE9BQU8sQ0FBQ0MsS0FBUixDQUFjQyxLQUEvQixJQUF3Q0osSUFBeEMsSUFBZ0QsT0FBT0EsSUFBUCxLQUFnQixRQUFwRSxFQUE4RTtBQUM1RSxRQUFJQSxJQUFJLFlBQVlFLE9BQU8sQ0FBQ0MsS0FBUixDQUFjQyxLQUFkLENBQW9CQyxNQUF4QyxFQUFnRDtBQUM5Q0osZ0JBQVUsR0FBRyxJQUFiO0FBQ0QsS0FGRCxNQUVPLElBQUlLLE1BQU0sQ0FBQ0MsY0FBUCxDQUFzQlAsSUFBdEIsTUFBZ0NNLE1BQU0sQ0FBQ0UsU0FBM0MsRUFBc0Q7QUFDM0RGLFlBQU0sQ0FBQ0csSUFBUCxDQUFZVCxJQUFaLEVBQWtCVSxPQUFsQixDQUEyQkMsR0FBRCxJQUFTO0FBQ2pDLFlBQUlYLElBQUksQ0FBQ1csR0FBRCxDQUFKLFlBQXFCVCxPQUFPLENBQUNDLEtBQVIsQ0FBY0MsS0FBZCxDQUFvQkMsTUFBN0MsRUFBcUQ7QUFDbkRKLG9CQUFVLEdBQUcsSUFBYjtBQUNEO0FBQ0YsT0FKRDtBQUtEO0FBQ0Y7O0FBQ0QsTUFBSUEsVUFBSixFQUFnQjtBQUNkUixRQUFJLENBQ0Ysa0VBQ0UsNkRBREYsR0FFRSwrQ0FIQSxDQUFKO0FBS0Q7QUFDRixDLENBRUQ7QUFDQTs7O0FBQ0EsTUFBTW1CLEdBQUcsR0FBR0MsQ0FBQyxJQUFJQSxDQUFDLEdBQUcsQ0FBckIsQyxDQUVBO0FBQ0E7O0FBQ0E7OztBQUNBLE1BQU1DLE9BQU8sR0FBSUMsSUFBRCxJQUFVO0FBQ3hCLE1BQUlBLElBQUksQ0FBQ0Msa0JBQVQsRUFBNkI7QUFDM0JELFFBQUksQ0FBQ0Msa0JBQUw7QUFDQSxXQUFPRCxJQUFJLENBQUNDLGtCQUFaO0FBQ0Q7O0FBQ0QsTUFBSUQsSUFBSSxDQUFDRSxXQUFULEVBQXNCO0FBQ3BCRixRQUFJLENBQUNFLFdBQUwsQ0FBaUJDLElBQWpCO0FBQ0FILFFBQUksQ0FBQ0UsV0FBTCxHQUFtQixJQUFuQjtBQUNEO0FBQ0YsQ0FURDs7QUFVQSxNQUFNRSxhQUFhLEdBQUcvQixNQUFNLENBQUNDLGFBQVAsR0FDbEIsQ0FBQzBCLElBQUQsRUFBT0ssQ0FBUCxLQUFhO0FBQ2IsUUFBTXBCLElBQUksR0FBR2UsSUFBSSxDQUFDTSxVQUFMLENBQWdCRCxDQUFoQixDQUFiO0FBQ0FyQixhQUFXLENBQUNDLElBQUQsQ0FBWDtBQUNBZSxNQUFJLENBQUNPLFdBQUwsR0FBbUJ0QixJQUFuQjtBQUNELENBTG1CLEdBTWxCLENBQUNlLElBQUQsRUFBT0ssQ0FBUCxLQUFhO0FBQ2JMLE1BQUksQ0FBQ08sV0FBTCxHQUFtQlAsSUFBSSxDQUFDTSxVQUFMLENBQWdCRCxDQUFoQixDQUFuQjtBQUNELENBUkg7O0FBU0EsTUFBTUcsS0FBSyxHQUFJUixJQUFELElBQVU7QUFDdEIsTUFBSUEsSUFBSSxDQUFDUyxTQUFULEVBQW9CO0FBQ2xCQyxnQkFBWSxDQUFDVixJQUFJLENBQUNTLFNBQU4sQ0FBWjtBQUNBLFdBQU9ULElBQUksQ0FBQ1MsU0FBWjtBQUNEO0FBQ0YsQ0FMRDs7QUFNQSxNQUFNRSxPQUFPLEdBQUcsQ0FBQ1gsSUFBRCxFQUFPSyxDQUFQLEVBQVVPLFdBQVYsS0FBMEI7QUFDeEMsTUFBSVAsQ0FBQyxDQUFDUSxRQUFOLEVBQWdCO0FBQ2Q7QUFDQTtBQUNBLFFBQUliLElBQUksQ0FBQ2Msa0JBQVQsRUFBNkI7QUFDM0IsWUFBTUMsY0FBYyxHQUFHZixJQUFJLENBQUNjLGtCQUFMLENBQXdCVCxDQUF4QixDQUF2Qjs7QUFDQSxVQUFJVSxjQUFKLEVBQW9CO0FBQ2xCLFlBQUkxQyxNQUFNLENBQUNDLGFBQVAsSUFBd0IsT0FBT3lDLGNBQVAsS0FBMEIsVUFBdEQsRUFBa0U7QUFDaEVyQyxjQUFJLENBQ0YsMkRBQ0UsMkNBRkEsQ0FBSjtBQUlEOztBQUNEc0IsWUFBSSxDQUFDQyxrQkFBTCxHQUEwQmMsY0FBMUI7QUFDRDtBQUNGLEtBZGEsQ0FlZDs7O0FBQ0FYLGlCQUFhLENBQUNKLElBQUQsRUFBT0ssQ0FBUCxDQUFiO0FBQ0QsR0FqQkQsTUFpQk87QUFDTDtBQUNBO0FBQ0E7QUFDQSxRQUFJTCxJQUFJLENBQUNnQixJQUFMLEtBQWMsSUFBZCxJQUFzQmhCLElBQUksQ0FBQ2dCLElBQUwsS0FBY0MsU0FBcEMsSUFBaUQsQ0FBQ0MsS0FBSyxDQUFDQyxPQUFOLENBQWNuQixJQUFJLENBQUNnQixJQUFuQixDQUF0RCxFQUFnRjtBQUM5RWpCLGFBQU8sQ0FBQ0MsSUFBRCxDQUFQO0FBQ0FZLGlCQUFXO0FBQ1osS0FIRCxNQUdPLElBQUlaLElBQUksQ0FBQ29CLFNBQVQsRUFBb0I7QUFDekI7QUFDQWhCLG1CQUFhLENBQUNKLElBQUQsRUFBT0ssQ0FBUCxDQUFiO0FBQ0FPLGlCQUFXO0FBQ1osS0FKTSxNQUlBO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQWIsYUFBTyxDQUFDQyxJQUFELENBQVAsQ0FSSyxDQVNMOztBQUNBUSxXQUFLLENBQUNSLElBQUQsQ0FBTDtBQUNEO0FBQ0Y7QUFDRixDQTFDRDtBQTJDQTs7O0FBRUEsU0FBU3FCLGdCQUFULENBQTBCZixVQUExQixFQUFzQ1UsSUFBdEMsRUFBNENGLGtCQUE1QyxFQUFnRTtBQUM5RCxRQUFNO0FBQUVRLFdBQU8sRUFBRXRCO0FBQVgsTUFBb0JuQixNQUFNLENBQUMsRUFBRCxDQUFoQztBQUNBLFFBQU0sR0FBRytCLFdBQUgsSUFBa0JqQyxVQUFVLENBQUNrQixHQUFELEVBQU0sQ0FBTixDQUFsQyxDQUY4RCxDQUk5RDs7QUFDQUcsTUFBSSxDQUFDTSxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBTixNQUFJLENBQUNnQixJQUFMLEdBQVlBLElBQVo7QUFDQWhCLE1BQUksQ0FBQ2Msa0JBQUwsR0FBMEJBLGtCQUExQixDQVA4RCxDQVM5RDtBQUNBOztBQUNBaEMsU0FBTyxDQUFDLE1BQU07QUFDWjtBQUNBaUIsV0FBTyxDQUFDQyxJQUFELENBQVAsQ0FGWSxDQUlaO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBQ0FBLFFBQUksQ0FBQ0UsV0FBTCxHQUFtQnFCLE9BQU8sQ0FBQ0MsV0FBUixDQUFvQixNQUNyQ0QsT0FBTyxDQUFDRSxPQUFSLENBQWlCcEIsQ0FBRCxJQUFPO0FBQ3JCTSxhQUFPLENBQUNYLElBQUQsRUFBT0ssQ0FBUCxFQUFVTyxXQUFWLENBQVA7QUFDRCxLQUZELENBRGlCLENBQW5CLENBVFksQ0FlWjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFFBQUksQ0FBQ1osSUFBSSxDQUFDb0IsU0FBVixFQUFxQjtBQUNuQjtBQUNBO0FBQ0E7QUFDQXBCLFVBQUksQ0FBQ1MsU0FBTCxHQUFpQmlCLFVBQVUsQ0FBQyxNQUFNO0FBQ2hDLFlBQUksQ0FBQzFCLElBQUksQ0FBQ29CLFNBQVYsRUFBcUI7QUFDbkJyQixpQkFBTyxDQUFDQyxJQUFELENBQVA7QUFDRDtBQUNGLE9BSjBCLEVBSXhCLElBSndCLENBQTNCO0FBS0Q7QUFDRixHQTlCTSxFQThCSmdCLElBOUJJLENBQVA7QUFnQ0FwQyxXQUFTLENBQUMsTUFBTTtBQUNkO0FBQ0FvQixRQUFJLENBQUNvQixTQUFMLEdBQWlCLElBQWpCLENBRmMsQ0FJZDs7QUFDQVosU0FBSyxDQUFDUixJQUFELENBQUwsQ0FMYyxDQU9kO0FBQ0E7O0FBQ0EsUUFBSSxDQUFDQSxJQUFJLENBQUNFLFdBQVYsRUFBdUI7QUFDckI7QUFDQTtBQUNBLFVBQUlnQixLQUFLLENBQUNDLE9BQU4sQ0FBY0gsSUFBZCxDQUFKLEVBQXlCO0FBQ3ZCO0FBQ0FoQixZQUFJLENBQUNFLFdBQUwsR0FBbUJxQixPQUFPLENBQUNDLFdBQVIsQ0FBb0IsTUFDckNELE9BQU8sQ0FBQ0UsT0FBUixDQUFpQnBCLENBQUQsSUFBTztBQUNyQk0saUJBQU8sQ0FBQ1gsSUFBRCxFQUFPSyxDQUFQLEVBQVVPLFdBQVYsQ0FBUDtBQUNELFNBRkQsQ0FEaUIsQ0FBbkI7QUFLRDs7QUFDREEsaUJBQVc7QUFDWixLQXJCYSxDQXVCZDs7O0FBQ0EsV0FBTyxNQUFNYixPQUFPLENBQUNDLElBQUQsQ0FBcEI7QUFDRCxHQXpCUSxFQXlCTixFQXpCTSxDQUFUO0FBMkJBLFNBQU9BLElBQUksQ0FBQ08sV0FBWjtBQUNELEMsQ0FFRDtBQUNBOzs7QUFDQSxNQUFNb0IsVUFBVSxHQUFHdEQsTUFBTSxDQUFDdUQsUUFBUCxHQUNkdEIsVUFBRCxJQUFnQmlCLE9BQU8sQ0FBQ0MsV0FBUixDQUFvQmxCLFVBQXBCLENBREQsR0FFZmUsZ0JBRko7QUFyTEFwRCxNQUFNLENBQUM0RCxhQUFQLENBeUxleEQsTUFBTSxDQUFDQyxhQUFQLEdBQ1gsQ0FBQ2dDLFVBQUQsRUFBYVUsSUFBYixFQUFtQkYsa0JBQW5CLEtBQTBDO0FBQzFDLE1BQUksT0FBT1IsVUFBUCxLQUFzQixVQUExQixFQUFzQztBQUNwQzVCLFFBQUksQ0FDRiw2R0FDbUMsT0FBTzRCLFVBRDFDLE1BREUsQ0FBSjtBQUlEOztBQUNELE1BQUlVLElBQUksSUFBSSxDQUFDRSxLQUFLLENBQUNDLE9BQU4sQ0FBY0gsSUFBZCxDQUFiLEVBQWtDO0FBQ2hDdEMsUUFBSSxDQUNGLDRHQUNtQyxPQUFPc0MsSUFEMUMsTUFERSxDQUFKO0FBSUQ7O0FBQ0QsTUFBSUYsa0JBQWtCLElBQUksT0FBT0Esa0JBQVAsS0FBOEIsVUFBeEQsRUFBb0U7QUFDbEVwQyxRQUFJLENBQ0Ysb0hBQzJDLE9BQU9vQyxrQkFEbEQsTUFERSxDQUFKO0FBSUQ7O0FBQ0QsU0FBT2EsVUFBVSxDQUFDckIsVUFBRCxFQUFhVSxJQUFiLEVBQW1CRixrQkFBbkIsQ0FBakI7QUFDRCxDQXJCWSxHQXNCWGEsVUEvTUosRTs7Ozs7Ozs7Ozs7QUNBQSxJQUFJRyxRQUFKOztBQUFhN0QsTUFBTSxDQUFDQyxJQUFQLENBQVksZ0NBQVosRUFBNkM7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQzBELFlBQVEsR0FBQzFELENBQVQ7QUFBVzs7QUFBdkIsQ0FBN0MsRUFBc0UsQ0FBdEU7QUFBYkgsTUFBTSxDQUFDOEQsTUFBUCxDQUFjO0FBQUM1RCxTQUFPLEVBQUMsTUFBSTZEO0FBQWIsQ0FBZDtBQUF5QyxJQUFJaEUsS0FBSixFQUFVaUUsVUFBVixFQUFxQkMsSUFBckI7QUFBMEJqRSxNQUFNLENBQUNDLElBQVAsQ0FBWSxPQUFaLEVBQW9CO0FBQUNDLFNBQU8sQ0FBQ0MsQ0FBRCxFQUFHO0FBQUNKLFNBQUssR0FBQ0ksQ0FBTjtBQUFRLEdBQXBCOztBQUFxQjZELFlBQVUsQ0FBQzdELENBQUQsRUFBRztBQUFDNkQsY0FBVSxHQUFDN0QsQ0FBWDtBQUFhLEdBQWhEOztBQUFpRDhELE1BQUksQ0FBQzlELENBQUQsRUFBRztBQUFDOEQsUUFBSSxHQUFDOUQsQ0FBTDtBQUFPOztBQUFoRSxDQUFwQixFQUFzRixDQUF0RjtBQUF5RixJQUFJdUQsVUFBSjtBQUFlMUQsTUFBTSxDQUFDQyxJQUFQLENBQVksaUJBQVosRUFBOEI7QUFBQ0MsU0FBTyxDQUFDQyxDQUFELEVBQUc7QUFBQ3VELGNBQVUsR0FBQ3ZELENBQVg7QUFBYTs7QUFBekIsQ0FBOUIsRUFBeUQsQ0FBekQ7O0FBRzVKLFNBQVM0RCxXQUFULENBQXFCRyxPQUFyQixFQUE4QjtBQUMzQyxTQUFPQyxTQUFTLElBQUk7QUFDbEIsVUFBTUMsZUFBZSxHQUFHLE9BQU9GLE9BQVAsS0FBbUIsVUFBbkIsR0FBZ0M7QUFBRUcsbUJBQWEsRUFBRUg7QUFBakIsS0FBaEMsR0FBNkRBLE9BQXJGO0FBQ0EsVUFBTTtBQUFFRyxtQkFBRjtBQUFpQkMsVUFBSSxHQUFHO0FBQXhCLFFBQWlDRixlQUF2QztBQUVBLFVBQU1HLFdBQVcsR0FBR1AsVUFBVSxDQUFDLENBQUNRLEtBQUQsRUFBUUMsR0FBUixLQUFnQjtBQUM3QyxZQUFNekQsSUFBSSxHQUFHMEMsVUFBVSxDQUFDLE1BQU1XLGFBQWEsQ0FBQ0csS0FBRCxDQUFiLElBQXdCLEVBQS9CLENBQXZCO0FBQ0EsYUFBTyxvQkFBQyxTQUFEO0FBQVcsV0FBRyxFQUFFQztBQUFoQixTQUF5QkQsS0FBekIsRUFBb0N4RCxJQUFwQyxFQUFQO0FBQ0QsS0FINkIsQ0FBOUI7QUFLQSxXQUFPc0QsSUFBSSxHQUFHTCxJQUFJLENBQUNNLFdBQUQsQ0FBUCxHQUF1QkEsV0FBbEM7QUFDRCxHQVZEO0FBV0QsQyIsImZpbGUiOiIvcGFja2FnZXMvcmVhY3QtbWV0ZW9yLWRhdGEuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBnbG9iYWwgTWV0ZW9yKi9cbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5cbmlmIChNZXRlb3IuaXNEZXZlbG9wbWVudCkge1xuICBjb25zdCB2ID0gUmVhY3QudmVyc2lvbi5zcGxpdCgnLicpO1xuICBpZiAodlswXSA8IDE2IHx8IHZbMV0gPCA4KSB7XG4gICAgY29uc29sZS53YXJuKCdyZWFjdC1tZXRlb3ItZGF0YSAyLnggcmVxdWlyZXMgUmVhY3QgdmVyc2lvbiA+PSAxNi44LicpO1xuICB9XG59XG5cbmV4cG9ydCB7IGRlZmF1bHQgYXMgdXNlVHJhY2tlciB9IGZyb20gJy4vdXNlVHJhY2tlcic7XG5leHBvcnQgeyBkZWZhdWx0IGFzIHdpdGhUcmFja2VyIH0gZnJvbSAnLi93aXRoVHJhY2tlci5qc3gnO1xuIiwiLyogZ2xvYmFsIE1ldGVvciwgUGFja2FnZSwgVHJhY2tlciAqL1xuaW1wb3J0IFJlYWN0LCB7IHVzZVJlZHVjZXIsIHVzZUVmZmVjdCwgdXNlUmVmLCB1c2VNZW1vIH0gZnJvbSAncmVhY3QnO1xuXG4vLyBVc2UgUmVhY3Qud2FybigpIGlmIGF2YWlsYWJsZSAoc2hvdWxkIHNoaXAgaW4gUmVhY3QgMTYuOSkuXG5jb25zdCB3YXJuID0gUmVhY3Qud2FybiB8fCBjb25zb2xlLndhcm4uYmluZChjb25zb2xlKTtcblxuLy8gV2FybnMgaWYgZGF0YSBpcyBhIE1vbmdvLkN1cnNvciBvciBhIFBPSk8gY29udGFpbmluZyBhIE1vbmdvLkN1cnNvci5cbmZ1bmN0aW9uIGNoZWNrQ3Vyc29yKGRhdGEpIHtcbiAgbGV0IHNob3VsZFdhcm4gPSBmYWxzZTtcbiAgaWYgKFBhY2thZ2UubW9uZ28gJiYgUGFja2FnZS5tb25nby5Nb25nbyAmJiBkYXRhICYmIHR5cGVvZiBkYXRhID09PSAnb2JqZWN0Jykge1xuICAgIGlmIChkYXRhIGluc3RhbmNlb2YgUGFja2FnZS5tb25nby5Nb25nby5DdXJzb3IpIHtcbiAgICAgIHNob3VsZFdhcm4gPSB0cnVlO1xuICAgIH0gZWxzZSBpZiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKGRhdGEpID09PSBPYmplY3QucHJvdG90eXBlKSB7XG4gICAgICBPYmplY3Qua2V5cyhkYXRhKS5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgaWYgKGRhdGFba2V5XSBpbnN0YW5jZW9mIFBhY2thZ2UubW9uZ28uTW9uZ28uQ3Vyc29yKSB7XG4gICAgICAgICAgc2hvdWxkV2FybiA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuICBpZiAoc2hvdWxkV2Fybikge1xuICAgIHdhcm4oXG4gICAgICAnV2FybmluZzogeW91ciByZWFjdGl2ZSBmdW5jdGlvbiBpcyByZXR1cm5pbmcgYSBNb25nbyBjdXJzb3IuICdcbiAgICAgICsgJ1RoaXMgdmFsdWUgd2lsbCBub3QgYmUgcmVhY3RpdmUuIFlvdSBwcm9iYWJseSB3YW50IHRvIGNhbGwgJ1xuICAgICAgKyAnYC5mZXRjaCgpYCBvbiB0aGUgY3Vyc29yIGJlZm9yZSByZXR1cm5pbmcgaXQuJ1xuICAgICk7XG4gIH1cbn1cblxuLy8gVXNlZCB0byBjcmVhdGUgYSBmb3JjZVVwZGF0ZSBmcm9tIHVzZVJlZHVjZXIuIEZvcmNlcyB1cGRhdGUgYnlcbi8vIGluY3JlbWVudGluZyBhIG51bWJlciB3aGVuZXZlciB0aGUgZGlzcGF0Y2ggbWV0aG9kIGlzIGludm9rZWQuXG5jb25zdCBmdXIgPSB4ID0+IHggKyAxO1xuXG4vLyBUaGUgZm9sbG93IGZ1bmN0aW9ucyB3ZXJlIGhvaXN0ZWQgb3V0IG9mIHRoZSBjbG9zdXJlIHRvIHJlZHVjZSBhbGxvY2F0aW9ucy5cbi8vIFNpbmNlIHRoZXkgbm8gbG9uZ2VyIGhhdmUgYWNjZXNzIHRvIHRoZSBsb2NhbCB2YXJzLCB3ZSBwYXNzIHRoZW0gaW4gYW5kIG11dGF0ZSBoZXJlLlxuLyogZXNsaW50LWRpc2FibGUgbm8tcGFyYW0tcmVhc3NpZ24gKi9cbmNvbnN0IGRpc3Bvc2UgPSAocmVmcykgPT4ge1xuICBpZiAocmVmcy5jb21wdXRhdGlvbkNsZWFudXApIHtcbiAgICByZWZzLmNvbXB1dGF0aW9uQ2xlYW51cCgpO1xuICAgIGRlbGV0ZSByZWZzLmNvbXB1dGF0aW9uQ2xlYW51cDtcbiAgfVxuICBpZiAocmVmcy5jb21wdXRhdGlvbikge1xuICAgIHJlZnMuY29tcHV0YXRpb24uc3RvcCgpO1xuICAgIHJlZnMuY29tcHV0YXRpb24gPSBudWxsO1xuICB9XG59O1xuY29uc3QgcnVuUmVhY3RpdmVGbiA9IE1ldGVvci5pc0RldmVsb3BtZW50XG4gID8gKHJlZnMsIGMpID0+IHtcbiAgICBjb25zdCBkYXRhID0gcmVmcy5yZWFjdGl2ZUZuKGMpO1xuICAgIGNoZWNrQ3Vyc29yKGRhdGEpO1xuICAgIHJlZnMudHJhY2tlckRhdGEgPSBkYXRhO1xuICB9XG4gIDogKHJlZnMsIGMpID0+IHtcbiAgICByZWZzLnRyYWNrZXJEYXRhID0gcmVmcy5yZWFjdGl2ZUZuKGMpO1xuICB9O1xuY29uc3QgY2xlYXIgPSAocmVmcykgPT4ge1xuICBpZiAocmVmcy5kaXNwb3NlSWQpIHtcbiAgICBjbGVhclRpbWVvdXQocmVmcy5kaXNwb3NlSWQpO1xuICAgIGRlbGV0ZSByZWZzLmRpc3Bvc2VJZDtcbiAgfVxufTtcbmNvbnN0IHRyYWNrZWQgPSAocmVmcywgYywgZm9yY2VVcGRhdGUpID0+IHtcbiAgaWYgKGMuZmlyc3RSdW4pIHtcbiAgICAvLyBJZiB0aGVyZSBpcyBhIGNvbXB1dGF0aW9uSGFuZGxlciwgcGFzcyBpdCB0aGUgY29tcHV0YXRpb24sIGFuZCBzdG9yZSB0aGVcbiAgICAvLyByZXN1bHQsIHdoaWNoIG1heSBiZSBhIGNsZWFudXAgbWV0aG9kLlxuICAgIGlmIChyZWZzLmNvbXB1dGF0aW9uSGFuZGxlcikge1xuICAgICAgY29uc3QgY2xlYW51cEhhbmRsZXIgPSByZWZzLmNvbXB1dGF0aW9uSGFuZGxlcihjKTtcbiAgICAgIGlmIChjbGVhbnVwSGFuZGxlcikge1xuICAgICAgICBpZiAoTWV0ZW9yLmlzRGV2ZWxvcG1lbnQgJiYgdHlwZW9mIGNsZWFudXBIYW5kbGVyICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgd2FybihcbiAgICAgICAgICAgICdXYXJuaW5nOiBDb21wdXRhdGlvbiBoYW5kbGVyIHNob3VsZCByZXR1cm4gYSBmdW5jdGlvbiAnXG4gICAgICAgICAgICArICd0byBiZSB1c2VkIGZvciBjbGVhbnVwIG9yIHJldHVybiBub3RoaW5nLidcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICAgIHJlZnMuY29tcHV0YXRpb25DbGVhbnVwID0gY2xlYW51cEhhbmRsZXI7XG4gICAgICB9XG4gICAgfVxuICAgIC8vIEFsd2F5cyBydW4gdGhlIHJlYWN0aXZlRm4gb24gZmlyc3RSdW5cbiAgICBydW5SZWFjdGl2ZUZuKHJlZnMsIGMpO1xuICB9IGVsc2Uge1xuICAgIC8vIElmIGRlcHMgYXJlIGFueXRoaW5nIG90aGVyIHRoYW4gYW4gYXJyYXksIHN0b3AgY29tcHV0YXRpb24gYW5kIGxldCBuZXh0IHJlbmRlclxuICAgIC8vIGhhbmRsZSByZWFjdGl2ZUZuLiBUaGVzZSBudWxsIGFuZCB1bmRlZmluZWQgY2hlY2tzIGFyZSBvcHRpbWl6YXRpb25zIHRvIGF2b2lkXG4gICAgLy8gY2FsbGluZyBBcnJheS5pc0FycmF5IGluIHRoZXNlIGNhc2VzLlxuICAgIGlmIChyZWZzLmRlcHMgPT09IG51bGwgfHwgcmVmcy5kZXBzID09PSB1bmRlZmluZWQgfHwgIUFycmF5LmlzQXJyYXkocmVmcy5kZXBzKSkge1xuICAgICAgZGlzcG9zZShyZWZzKTtcbiAgICAgIGZvcmNlVXBkYXRlKCk7XG4gICAgfSBlbHNlIGlmIChyZWZzLmlzTW91bnRlZCkge1xuICAgICAgLy8gT25seSBydW4gdGhlIHJlYWN0aXZlRm4gaWYgdGhlIGNvbXBvbmVudCBpcyBtb3VudGVkLlxuICAgICAgcnVuUmVhY3RpdmVGbihyZWZzLCBjKTtcbiAgICAgIGZvcmNlVXBkYXRlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIElmIHdlIGdvdCBoZXJlLCB0aGVuIGEgcmVhY3RpdmUgdXBkYXRlIGhhcHBlbmVkIGJlZm9yZSB0aGUgcmVuZGVyIHdhc1xuICAgICAgLy8gY29tbWl0dGVkIC0gYmVmb3JlIHVzZUVmZmVjdCBoYXMgcnVuLiBXZSBkb24ndCB3YW50IHRvIHJ1biB0aGUgcmVhY3RpdmVGblxuICAgICAgLy8gd2hpbGUgd2UgYXJlIG5vdCBzdXJlIHRoaXMgcmVuZGVyIHdpbGwgYmUgY29tbWl0dGVkLCBzbyB3ZSdsbCBkaXNwb3NlIG9mIHRoZVxuICAgICAgLy8gY29tcHV0YXRpb24sIGFuZCBzZXQgZXZlcnl0aGluZyB1cCB0byBiZSByZXN0YXJ0ZWQgaW4gdXNlRWZmZWN0IGlmIG5lZWRlZC5cbiAgICAgIC8vIE5PVEU6IElmIHdlIGRvbid0IHJ1biB0aGUgdXNlcidzIHJlYWN0aXZlRm4gd2hlbiBhIGNvbXB1dGF0aW9uIHVwZGF0ZXMsIHdlJ2xsXG4gICAgICAvLyBsZWF2ZSB0aGUgY29tcHV0YXRpb24gaW4gYSBub24tcmVhY3RpdmUgc3RhdGUgLSBzbyB3ZSdsbCBkaXNwb3NlIGhlcmUgYW5kIGxldFxuICAgICAgLy8gdGhlIHVzZUVmZmVjdCBob29rIHJlY3JlYXRlIHRoZSBjb21wdXRhdGlvbiBsYXRlci5cbiAgICAgIGRpc3Bvc2UocmVmcyk7XG4gICAgICAvLyBNaWdodCBhcyB3ZWxsIGNsZWFyIHRoZSB0aW1lb3V0IVxuICAgICAgY2xlYXIocmVmcyk7XG4gICAgfVxuICB9XG59O1xuLyogZXNsaW50LWVuYWJsZSBuby1wYXJhbS1yZWFzc2lnbiAqL1xuXG5mdW5jdGlvbiB1c2VUcmFja2VyQ2xpZW50KHJlYWN0aXZlRm4sIGRlcHMsIGNvbXB1dGF0aW9uSGFuZGxlcikge1xuICBjb25zdCB7IGN1cnJlbnQ6IHJlZnMgfSA9IHVzZVJlZih7fSk7XG4gIGNvbnN0IFssIGZvcmNlVXBkYXRlXSA9IHVzZVJlZHVjZXIoZnVyLCAwKTtcblxuICAvLyBBbHdheXMgaGF2ZSB1cCB0byBkYXRlIGRlcHMgYW5kIGNvbXB1dGF0aW9ucyBpbiBhbGwgY29udGV4dHNcbiAgcmVmcy5yZWFjdGl2ZUZuID0gcmVhY3RpdmVGbjtcbiAgcmVmcy5kZXBzID0gZGVwcztcbiAgcmVmcy5jb21wdXRhdGlvbkhhbmRsZXIgPSBjb21wdXRhdGlvbkhhbmRsZXI7XG5cbiAgLy8gV2UgYXJlIGFidXNpbmcgdXNlTWVtbyBhIGxpdHRsZSBiaXQsIHVzaW5nIGl0IGZvciBpdCdzIGRlcHNcbiAgLy8gY29tcGFyZSwgYnV0IG5vdCBmb3IgaXQncyBtZW1vaXphdGlvbi5cbiAgdXNlTWVtbygoKSA9PiB7XG4gICAgLy8gaWYgd2UgYXJlIHJlLWNyZWF0aW5nIHRoZSBjb21wdXRhdGlvbiwgd2UgbmVlZCB0byBzdG9wIHRoZSBvbGQgb25lLlxuICAgIGRpc3Bvc2UocmVmcyk7XG5cbiAgICAvLyBVc2UgVHJhY2tlci5ub25yZWFjdGl2ZSBpbiBjYXNlIHdlIGFyZSBpbnNpZGUgYSBUcmFja2VyIENvbXB1dGF0aW9uLlxuICAgIC8vIFRoaXMgY2FuIGhhcHBlbiBpZiBzb21lb25lIGNhbGxzIGBSZWFjdERPTS5yZW5kZXJgIGluc2lkZSBhIENvbXB1dGF0aW9uLlxuICAgIC8vIEluIHRoYXQgY2FzZSwgd2Ugd2FudCB0byBvcHQgb3V0IG9mIHRoZSBub3JtYWwgYmVoYXZpb3Igb2YgbmVzdGVkXG4gICAgLy8gQ29tcHV0YXRpb25zLCB3aGVyZSBpZiB0aGUgb3V0ZXIgb25lIGlzIGludmFsaWRhdGVkIG9yIHN0b3BwZWQsXG4gICAgLy8gaXQgc3RvcHMgdGhlIGlubmVyIG9uZS5cbiAgICByZWZzLmNvbXB1dGF0aW9uID0gVHJhY2tlci5ub25yZWFjdGl2ZSgoKSA9PlxuICAgICAgVHJhY2tlci5hdXRvcnVuKChjKSA9PiB7XG4gICAgICAgIHRyYWNrZWQocmVmcywgYywgZm9yY2VVcGRhdGUpO1xuICAgICAgfSlcbiAgICApO1xuXG4gICAgLy8gV2UgYXJlIGNyZWF0aW5nIGEgc2lkZSBlZmZlY3QgaW4gcmVuZGVyLCB3aGljaCBjYW4gYmUgcHJvYmxlbWF0aWMgaW4gc29tZSBjYXNlcywgc3VjaCBhc1xuICAgIC8vIFN1c3BlbnNlIG9yIGNvbmN1cnJlbnQgcmVuZGVyaW5nIG9yIGlmIGFuIGVycm9yIGlzIHRocm93biBhbmQgaGFuZGxlZCBieSBhbiBlcnJvciBib3VuZGFyeS5cbiAgICAvLyBXZSBzdGlsbCB3YW50IHN5bmNocm9ub3VzIHJlbmRlcmluZyBmb3IgYSBudW1iZXIgb2YgcmVhc29uIChzZWUgcmVhZG1lKSwgc28gd2Ugd29yayBhcm91bmRcbiAgICAvLyBwb3NzaWJsZSBtZW1vcnkvcmVzb3VyY2UgbGVha3MgYnkgc2V0dGluZyBhIHRpbWUgb3V0IHRvIGF1dG9tYXRpY2FsbHkgY2xlYW4gZXZlcnl0aGluZyB1cCxcbiAgICAvLyBhbmQgd2F0Y2hpbmcgYSBzZXQgb2YgcmVmZXJlbmNlcyB0byBtYWtlIHN1cmUgZXZlcnl0aGluZyBpcyBjaG9yZW9ncmFwaGVkIGNvcnJlY3RseS5cbiAgICBpZiAoIXJlZnMuaXNNb3VudGVkKSB7XG4gICAgICAvLyBDb21wb25lbnRzIHlpZWxkIHRvIGFsbG93IHRoZSBET00gdG8gdXBkYXRlIGFuZCB0aGUgYnJvd3NlciB0byBwYWludCBiZWZvcmUgdXNlRWZmZWN0XG4gICAgICAvLyBpcyBydW4uIEluIGNvbmN1cnJlbnQgbW9kZSB0aGlzIGNhbiB0YWtlIHF1aXRlIGEgbG9uZyB0aW1lLCBzbyB3ZSBzZXQgYSAxMDAwbXMgdGltZW91dFxuICAgICAgLy8gdG8gYWxsb3cgZm9yIHRoYXQuXG4gICAgICByZWZzLmRpc3Bvc2VJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBpZiAoIXJlZnMuaXNNb3VudGVkKSB7XG4gICAgICAgICAgZGlzcG9zZShyZWZzKTtcbiAgICAgICAgfVxuICAgICAgfSwgMTAwMCk7XG4gICAgfVxuICB9LCBkZXBzKTtcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIC8vIE5vdyB0aGF0IHdlIGFyZSBtb3VudGVkLCB3ZSBjYW4gc2V0IHRoZSBmbGFnLCBhbmQgY2FuY2VsIHRoZSB0aW1lb3V0XG4gICAgcmVmcy5pc01vdW50ZWQgPSB0cnVlO1xuXG4gICAgLy8gV2UgYXJlIGNvbW1pdHRlZCwgY2xlYXIgdGhlIGRpc3Bvc2UgdGltZW91dFxuICAgIGNsZWFyKHJlZnMpO1xuXG4gICAgLy8gSWYgaXQgdG9vayBsb25nZXIgdGhhbiAxMDAwbXMgdG8gZ2V0IHRvIHVzZUVmZmVjdCwgb3IgYSByZWFjdGl2ZSB1cGRhdGUgaGFwcGVuZWRcbiAgICAvLyBiZWZvcmUgdXNlRWZmZWN0LCB3ZSB3aWxsIG5lZWQgdG8gZm9yY2VVcGRhdGUsIGFuZCByZXN0YXJ0IHRoZSBjb21wdXRhdGlvbi5cbiAgICBpZiAoIXJlZnMuY29tcHV0YXRpb24pIHtcbiAgICAgIC8vIElmIHdlIGhhdmUgZGVwcywgd2UgbmVlZCB0byBzZXQgdXAgYSBuZXcgY29tcHV0YXRpb24gYmVmb3JlIGZvcmNpbmcgdXBkYXRlLlxuICAgICAgLy8gSWYgd2UgaGF2ZSBOTyBkZXBzLCBpdCdsbCBiZSByZWNyZWF0ZWQgYW5kIHJlcnVuIG9uIHRoZSBuZXh0IHJlbmRlci5cbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGRlcHMpKSB7XG4gICAgICAgIC8vIFRoaXMgYWxzbyBydW5zIHJ1blJlYWN0aXZlRm5cbiAgICAgICAgcmVmcy5jb21wdXRhdGlvbiA9IFRyYWNrZXIubm9ucmVhY3RpdmUoKCkgPT5cbiAgICAgICAgICBUcmFja2VyLmF1dG9ydW4oKGMpID0+IHtcbiAgICAgICAgICAgIHRyYWNrZWQocmVmcywgYywgZm9yY2VVcGRhdGUpO1xuICAgICAgICAgIH0pXG4gICAgICAgICk7XG4gICAgICB9XG4gICAgICBmb3JjZVVwZGF0ZSgpO1xuICAgIH1cblxuICAgIC8vIHN0b3AgdGhlIGNvbXB1dGF0aW9uIG9uIHVubW91bnRcbiAgICByZXR1cm4gKCkgPT4gZGlzcG9zZShyZWZzKTtcbiAgfSwgW10pO1xuXG4gIHJldHVybiByZWZzLnRyYWNrZXJEYXRhO1xufVxuXG4vLyBXaGVuIHJlbmRlcmluZyBvbiB0aGUgc2VydmVyLCB3ZSBkb24ndCB3YW50IHRvIHVzZSB0aGUgVHJhY2tlci5cbi8vIFdlIG9ubHkgZG8gdGhlIGZpcnN0IHJlbmRlcmluZyBvbiB0aGUgc2VydmVyIHNvIHdlIGNhbiBnZXQgdGhlIGRhdGEgcmlnaHQgYXdheVxuY29uc3QgdXNlVHJhY2tlciA9IE1ldGVvci5pc1NlcnZlclxuICA/IChyZWFjdGl2ZUZuKSA9PiBUcmFja2VyLm5vbnJlYWN0aXZlKHJlYWN0aXZlRm4pXG4gIDogdXNlVHJhY2tlckNsaWVudDtcblxuZXhwb3J0IGRlZmF1bHQgTWV0ZW9yLmlzRGV2ZWxvcG1lbnRcbiAgPyAocmVhY3RpdmVGbiwgZGVwcywgY29tcHV0YXRpb25IYW5kbGVyKSA9PiB7XG4gICAgaWYgKHR5cGVvZiByZWFjdGl2ZUZuICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB3YXJuKFxuICAgICAgICAnV2FybmluZzogdXNlVHJhY2tlciBleHBlY3RlZCBhIGZ1bmN0aW9uIGluIGl0XFwncyBmaXJzdCBhcmd1bWVudCAnXG4gICAgICAgICsgYChyZWFjdGl2ZUZuKSwgYnV0IGdvdCB0eXBlIG9mICR7dHlwZW9mIHJlYWN0aXZlRm59LmBcbiAgICAgICk7XG4gICAgfVxuICAgIGlmIChkZXBzICYmICFBcnJheS5pc0FycmF5KGRlcHMpKSB7XG4gICAgICB3YXJuKFxuICAgICAgICAnV2FybmluZzogdXNlVHJhY2tlciBleHBlY3RlZCBhbiBhcnJheSBpbiBpdFxcJ3Mgc2Vjb25kIGFyZ3VtZW50ICdcbiAgICAgICAgKyBgKGRlcGVuZGVuY3kpLCBidXQgZ290IHR5cGUgb2YgJHt0eXBlb2YgZGVwc30uYFxuICAgICAgKTtcbiAgICB9XG4gICAgaWYgKGNvbXB1dGF0aW9uSGFuZGxlciAmJiB0eXBlb2YgY29tcHV0YXRpb25IYW5kbGVyICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB3YXJuKFxuICAgICAgICAnV2FybmluZzogdXNlVHJhY2tlciBleHBlY3RlZCBhIGZ1bmN0aW9uIGluIGl0XFwncyB0aGlyZCBhcmd1bWVudCdcbiAgICAgICAgKyBgKGNvbXB1dGF0aW9uSGFuZGxlciksIGJ1dCBnb3QgdHlwZSBvZiAke3R5cGVvZiBjb21wdXRhdGlvbkhhbmRsZXJ9LmBcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiB1c2VUcmFja2VyKHJlYWN0aXZlRm4sIGRlcHMsIGNvbXB1dGF0aW9uSGFuZGxlcik7XG4gIH1cbiAgOiB1c2VUcmFja2VyO1xuIiwiaW1wb3J0IFJlYWN0LCB7IGZvcndhcmRSZWYsIG1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgdXNlVHJhY2tlciBmcm9tICcuL3VzZVRyYWNrZXIuanMnO1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB3aXRoVHJhY2tlcihvcHRpb25zKSB7XG4gIHJldHVybiBDb21wb25lbnQgPT4ge1xuICAgIGNvbnN0IGV4cGFuZGVkT3B0aW9ucyA9IHR5cGVvZiBvcHRpb25zID09PSAnZnVuY3Rpb24nID8geyBnZXRNZXRlb3JEYXRhOiBvcHRpb25zIH0gOiBvcHRpb25zO1xuICAgIGNvbnN0IHsgZ2V0TWV0ZW9yRGF0YSwgcHVyZSA9IHRydWUgfSA9IGV4cGFuZGVkT3B0aW9ucztcblxuICAgIGNvbnN0IFdpdGhUcmFja2VyID0gZm9yd2FyZFJlZigocHJvcHMsIHJlZikgPT4ge1xuICAgICAgY29uc3QgZGF0YSA9IHVzZVRyYWNrZXIoKCkgPT4gZ2V0TWV0ZW9yRGF0YShwcm9wcykgfHwge30pO1xuICAgICAgcmV0dXJuIDxDb21wb25lbnQgcmVmPXtyZWZ9IHsuLi5wcm9wc30gey4uLmRhdGF9IC8+O1xuICAgIH0pO1xuXG4gICAgcmV0dXJuIHB1cmUgPyBtZW1vKFdpdGhUcmFja2VyKSA6IFdpdGhUcmFja2VyO1xuICB9O1xufVxuIl19
