(function () {

/* Package-scope variables */
var LaunchScreen;



/* Exports */
Package._define("launch-screen", {
  LaunchScreen: LaunchScreen
});

})();
